<?php
	class BidModel extends CI_Model
	{
		function __construct()
		{
			parent::__construct();
		}

		function newBid($data)
		{
			$this->db->insert('tblbid',$data);
			$row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

    }
?>