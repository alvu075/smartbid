<?php
	class AdminModel extends CI_Model
	{
		function __construct()
		{
			parent::__construct();
		}

		function login($email,$password)
		{
			$this->db->select();
			$this->db->from('tbluser');
			$this->db->where('userEmail',$email);
			$this->db->where('userPassword',$password);
			$this->db->where('status','Active');
			$query=$this->db->get();
			if($query->num_rows()==1)
			{
				return $query->result();
			}
			else
			{
				return false;
			}
		}

		function getUserDetails($id)
		{
			$this->db->select();
			$this->db->from('tbluser');
			$this->db->where('userID',$id);
			$query=$this->db->get();
			return $query->result();
		}

		function userRegistration($data)
		{
			$this->db->insert('tbluser',$data);
			$row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		function viewUser()
		{
			$this->db->select('userID,userName,userPhone,userEmail,userImage,role,status');
			$this->db->from('tbluser');
			$query=$this->db->get();
			return $query->result();
		}

		function editUser($id)
		{
			$this->db->select();
			$this->db->from('tbluser');
			$this->db->where('userID', $id);
			$query=$this->db->get();
			return $query->result();
		}

		function updateUser($data,$id)
		{
			$this->db->set($data);
		    $this->db->where('userID',$id);
		    $this->db->update('tbluser');
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		function allCategories()
		{
			$this->db->count_all_results('tblcategory');
			$this->db->from('tblcategory');
			return $query=$this->db->count_all_results();
		}

		function allProducts()
		{
			$this->db->count_all_results('tblproduct');
			$this->db->from('tblproduct');
			return $query=$this->db->count_all_results();
		}

		function allSeller()
		{
			$this->db->count_all_results('tblseller');
			$this->db->from('tblseller');
			return $query=$this->db->count_all_results();
		}

		function allBidder()
		{
			$this->db->count_all_results('tblbidder');
			$this->db->from('tblbidder');
			return $query=$this->db->count_all_results();
		}

		function updatePicture($id, $file_name)
		{
			$this->db->set("userImage", $file_name);
		    $this->db->where("userID", $id);
		    $this->db->update("tbluser");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		function updateProfileDetails($id,$data)
		{
			$this->db->set($data);
		    $this->db->where("userID", $id);
		    $this->db->update("tbluser");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}	
		}

		function getCurrentPassword($id)
		{
			$this->db->select('userPassword');
			$this->db->from('tbluser');
			$this->db->where('userID',$id);
			$query=$this->db->get();
			return $query->row()->userPassword;
		}

		function updatePassword($id,$data)
		{
			$this->db->set($data);
		    $this->db->where("userID", $id);
		    $this->db->update("tbluser");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}	
		}
	}
?>