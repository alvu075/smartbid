<?php
	class CustomerModel extends CI_Model
	{
		function __construct()
		{
			parent::__construct();
		}

		function getCategories()
		{
			$this->db->select();
			$this->db->from('tblcategory');
			$this->db->where('status','Active');
			$query=$this->db->get();
			return $query->result();
		}

		function getproducts()
		{
			if($this->session->userdata('bidderEmail_Phone'))
			{
				$bidderEmail = $this->session->userdata('bidderEmail_Phone');
			
				$this->db->select('sellerID');
				$this->db->from('tblseller');
				$this->db->where('sellerEmail',$bidderEmail);
				$query=$this->db->get();
				$result = $query->result();
				if ($result) 
				{
					foreach ($result as $row) 
					{
						$sellerID = $row->sellerID;
					}
					$this->db->select();
					$this->db->from('tblproduct');
					$this->db->where('status',1);
					$this->db->where('prodStatus','Active');
					$this->db->where('sellerID !=',$sellerID);
					$query=$this->db->get();
					return $query->result();
				}
				else
				{
					$this->db->select();
					$this->db->from('tblproduct');
					$this->db->where('status',1);
					$this->db->where('prodStatus','Active');
					$query=$this->db->get();
					return $query->result();
				}
				
			}
			else
			{
				$this->db->select();
				$this->db->from('tblproduct');
				$this->db->where('status',1);
				$this->db->where('prodStatus','Active');
				$query=$this->db->get();
				return $query->result();
			}
		}

		function getSellerFeedback()
		{
			$this->db->select();
			$this->db->from('tblfeedback');
			$query=$this->db->get();
			$result = $query->result();
			if ($result) 
			{
				foreach ($result as $row) 
				{
					$id = $row->id;
					//$bidderID = $row->bidderID;
					$sellerID = $row->sellerID;

					if($sellerID)
					{
						$this->db->select('f.*,s.sellerPhoto');
						$this->db->from('tblfeedback f');
						$this->db->join('tblseller s', 's.sellerID = f.sellerID');
						//$this->db->join('tblbidder b', 'b.bidderID = f.bidderID');
						$this->db->where('f.id',$id);
						$query=$this->db->get();
						return $query->result();
					}
				}
			}
		}
		
		function getBidderFeedback()
		{
			$this->db->select();
			$this->db->from('tblfeedback');
			$query=$this->db->get();
			$result = $query->result();
			if ($result) 
			{
				foreach ($result as $row) 
				{
					$id = $row->id;
					//$bidderID = $row->bidderID;
					$bidderID = $row->bidderID;
					if($bidderID)
					{
						$this->db->select('f.*,b.bidderPhoto');
						$this->db->from('tblfeedback f');
						//$this->db->join('tblseller s', 's.sellerID = f.sellerID');
						$this->db->join('tblbidder b', 'b.bidderID = f.bidderID');
						$this->db->where('f.id',$id);
						$query1=$this->db->get();
						return $query1->result();
					}
				}
			}
		}

		function verifybidderLogin($phone,$password)
		{
			$this->db->select();
			$this->db->from('tblbidder');
			$this->db->where('bidderPhone',$phone);
			$this->db->or_where('bidderEmail',$phone);
			$this->db->where('bidderPassword',$password);
			$this->db->where('status',1);
			$this->db->where('emailStatus',1);
			$query=$this->db->get();
			if($query->num_rows()==1)
			{
				return $query->row()->bidderID;
			}
			else
			{
				return false;
			}
		}

		function verifysellerLogin($phone,$password)
		{
			$this->db->select();
			$this->db->from('tblseller');
			$this->db->where('sellerPhone',$phone);
			$this->db->or_where('sellerEmail',$phone);
			$this->db->where('sellerPassword',$password);
			$this->db->where('status',1);
			$this->db->where('emailStatus',1);
			$query=$this->db->get();
			if($query->num_rows()==1)
			{
				return $query->row()->sellerID;
			}
			else
			{
				return false;
			}
		}

		function addBidder($data,$email)
		{
			$this->db->select();
			$this->db->from('tblbidder');
			$this->db->where('bidderEmail',$email);
			$query=$this->db->get();
			if($query->num_rows()==1)
			{
				return false;
			}
			else
			{
				$this->db->insert('tblbidder',$data);
				$row = $this->db->affected_rows();
				if($row)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}

		function addSeller($data,$email)
		{
			$this->db->select();
			$this->db->from('tblseller');
			$this->db->where('sellerEmail',$email);
			$query=$this->db->get();
			if($query->num_rows()==1)
			{
				return false;
			}
			else
			{
				$this->db->insert('tblseller',$data);
				$row = $this->db->affected_rows();
				if($row)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}

		function getProductsByID($id)
		{
			if($this->session->userdata('bidderEmail_Phone'))
			{
				$bidderEmail = $this->session->userdata('bidderEmail_Phone');
			
				$this->db->select('sellerID');
				$this->db->from('tblseller');
				$this->db->where('sellerEmail',$bidderEmail);
				$query=$this->db->get();
				$result = $query->result();
				foreach ($result as $row) 
				{
					$sellerID = $row->sellerID;
				}

				$this->db->select();
				$this->db->from('tblproduct');
				$this->db->where('catID',$id);
				$this->db->where('status',1);
				$this->db->where('prodStatus','Active');
				$this->db->where('sellerID !=',$sellerID);
				$query=$this->db->get();
				return $query->result();
			}
			else
			{
				$this->db->select();
				$this->db->from('tblproduct');
				$this->db->where('catID',$id);
				$this->db->where('status',1);
				$this->db->where('prodStatus','Active');
				$query=$this->db->get();
				return $query->result();
			}
		}

		function getProductsdetailByID($id)
		{
			$this->db->select();
			$this->db->from('tblproduct');
			$this->db->where('prodID',$id);
			$query=$this->db->get();
			return $query->result();
		}

		function bidsdetails($id)
		{
			$this->db->select('bb.*,b.bidID,b.date,b.time,max(b.bidAmount) as bidAmount');
			$this->db->from('tblbidder bb');
			$this->db->join('tblbid b', 'b.bidderID = bb.bidderID');
			$this->db->where('b.prodID',$id);
			$query=$this->db->get();
			return $query->result();
		}

		function addProduct($data)
		{
			$this->db->insert('tblproduct',$data);
			$row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		function bidderResetPassword($email,$data)
		{
			$this->db->set($data);
		    $this->db->where("bidderEmail", $email);
		    $this->db->update("tblbidder");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}	
		}

		function bidderPasswordReset($email,$code,$data)
		{
			$this->db->set($data);
		    $this->db->where("bidderEmail",$email);
		    $this->db->where("codeStatus",$code);
		    $this->db->update("tblbidder");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}	
		}

		function sellerResetPassword($email,$data)
		{
			$this->db->set($data);
		    $this->db->where("sellerEmail", $email);
		    $this->db->update("tblseller");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}	
		}

		function sellerPasswordReset($email,$code,$data)
		{
			$this->db->set($data);
		    $this->db->where("sellerEmail",$email);
		    $this->db->where("codeStatus",$code);
		    $this->db->update("tblseller");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}	
		}

		function getSellerDetails($id)
		{
			$this->db->select();
			$this->db->from('tblseller');
			$this->db->where('sellerID',$id);
			$query=$this->db->get();
			return $query->result();
		}

		function getBidderDetails($id)
		{
			$this->db->select();
			$this->db->from('tblbidder');
			$this->db->where('bidderID',$id);
			$query=$this->db->get();
			return $query->result();
		}

		function postFeedback($data)
		{
			$this->db->insert('tblfeedback',$data);
			$row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		function countmyProducts($id)
		{
			$this->db->count_all_results('tblproduct');
			$this->db->from('tblproduct');
			$this->db->where('sellerID',$id);
			return $query=$this->db->count_all_results();
		}

		function soldProducts($id)
		{
			$this->db->select('s.sellerName,c.catName,p.*');
			$this->db->from('tblseller s');
			$this->db->join('tblproduct p', 'p.sellerID = s.sellerID');
			$this->db->join('tblcategory c', 'c.catID = p.catID');
			$this->db->where('s.sellerID',$id);
			$this->db->where('p.prodStatus','Inactive');
			$this->db->where('p.status',1);
			$query=$this->db->get();
			return $query->result();
		}

		function countSoldProducts($id)
		{
			$this->db->count_all_results('tblproduct');
			$this->db->from('tblproduct');
			$this->db->where('sellerID',$id);
			$this->db->where('prodStatus','Inactive');
			$this->db->where('status',1);
			return $query=$this->db->count_all_results();
		}

		function unsoldProducts($id)
		{
			$this->db->select('s.sellerName,c.catName,p.*');
			$this->db->from('tblseller s');
			$this->db->join('tblproduct p', 'p.sellerID = s.sellerID');
			$this->db->join('tblcategory c', 'c.catID = p.catID');
			$this->db->where('s.sellerID',$id);
			$this->db->where('p.prodStatus','Active');
			$this->db->where('p.status',1);
			$query=$this->db->get();
			return $query->result();
		}

		function sellerProdBidDetail($id)
		{
			$this->db->select('p.prodName,c.catName,b.bidID,b.date,b.time,b.bidAmount,bb.bidderName');
			$this->db->from('tblseller s');
			$this->db->join('tblproduct p', 'p.sellerID = s.sellerID');
			$this->db->join('tblcategory c', 'c.catID = p.catID');
			$this->db->join('tblbid b', 'b.prodID = p.prodID');
			$this->db->join('tblbidder bb', 'b.bidderID = bb.bidderID');
			$this->db->where('s.sellerID',$id);
			$this->db->order_by("p.prodID", "asc");
			$query=$this->db->get();
			return $query->result();
		}

		function countUnsoldProducts($id)
		{
			$this->db->count_all_results('tblproduct');
			$this->db->from('tblproduct');
			$this->db->where('sellerID',$id);
			$this->db->where('prodStatus','Active');
			$this->db->where('status',1);
			return $query=$this->db->count_all_results();
		}

		function bidderUpdatePicture($id, $file_name)
		{
			$this->db->set("bidderPhoto", $file_name);
		    $this->db->where("bidderID", $id);
		    $this->db->update("tblbidder");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		function sellerUpdatePicture($id, $file_name)
		{
			$this->db->set("sellerPhoto", $file_name);
		    $this->db->where("sellerID", $id);
		    $this->db->update("tblseller");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		function sellerUpdateProfile($id,$data)
		{
			$this->db->set($data);
		    $this->db->where("sellerID", $id);
		    $this->db->update("tblseller");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}	
		}

		function bidderUpdateProfile($id,$data)
		{
			$this->db->set($data);
		    $this->db->where("bidderID", $id);
		    $this->db->update("tblbidder");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}	
		}

		function updatesellerPassword($id,$data)
		{
			$this->db->set($data);
		    $this->db->where("sellerID", $id);
		    $this->db->update("tblseller");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}	
		}

		function updateBidderPassword($id,$data)
		{
			$this->db->set($data);
		    $this->db->where("bidderID", $id);
		    $this->db->update("tblbidder");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}	
		}

		function editProduct($id)
		{
			$this->db->select();
			$this->db->from('tblproduct');
			$this->db->where('prodID', $id);
			$query=$this->db->get();
			return $query->result();
		}

		function updateProduct($data,$id)
		{
			$this->db->set($data);
		    $this->db->where("prodID", $id);
		    $this->db->update("tblproduct");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		 function bidderemailVerified($bidderEmail)
		{
			$this->db->set("status",1);
			$this->db->set("emailStatus",1);
			$this->db->set("codeStatus",0);
		    $this->db->where("bidderEmail", $bidderEmail);
		    $this->db->update("tblbidder");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		function selleremailVerified($sellerEmail)
		{
			$this->db->set("status",1);
			$this->db->set("emailStatus",1);
			$this->db->set("codeStatus",0);
		    $this->db->where("sellerEmail", $sellerEmail);
		    $this->db->update("tblseller");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}
		}


    }
?>