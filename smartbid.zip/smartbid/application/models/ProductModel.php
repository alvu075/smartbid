<?php
	class ProductModel extends CI_Model
	{
		function __construct()
		{
			parent::__construct();
		}

		function allCategories()
		{
			$this->db->select();
			$this->db->from('tblcategory');
			$query=$this->db->get();
			return $query->result();
		}

		function allSeller()
		{
			$this->db->select();
			$this->db->from('tblseller');
			$query=$this->db->get();
			return $query->result();
		}
		function addProduct($data)
		{
			$this->db->insert('tblproduct',$data);
			$row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		function viewProduct()
		{
			$this->db->select('p.prodID,p.prodName,p.prodPrice,p.prodDescription,p.prodStatus,p.prodQuantity,p.prodStartDate,p.prodEndDate,p.prodImage,c.catName,s.sellerName');
			$this->db->from('tblproduct p');
			$this->db->join('tblcategory c', 'p.catID = c.catID');
			$this->db->join('tblseller s', 'p.sellerID = s.sellerID');
			$query=$this->db->get();
			return $query->result();
		}

		function newProducts()
		{
			$this->db->select('p.prodID,p.prodName,p.prodPrice,p.prodDescription,p.prodStatus,p.prodQuantity,p.prodStartDate,p.prodEndDate,p.status,p.prodImage,c.catName,s.sellerName');
			$this->db->from('tblproduct p');
			$this->db->join('tblcategory c', 'p.catID = c.catID');
			$this->db->join('tblseller s', 'p.sellerID = s.sellerID');
			$this->db->where('p.prodStatus','Active');
			$this->db->where('p.status',0);
			$query=$this->db->get();
			return $query->result();
		}


		function editProduct($id)
		{
			$this->db->select();
			$this->db->from('tblproduct');
			$this->db->where('prodID', $id);
			$query=$this->db->get();
			return $query->result();
		}

		function updateProduct($data,$id)
		{
			$this->db->set($data);
		    $this->db->where("prodID", $id);
		    $this->db->update("tblproduct");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		function editNewProduct($id)
		{
			$this->db->set('status',1);
		    $this->db->where("prodID", $id);
		    $this->db->update("tblproduct");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		function countUnsoldProducts($id)
		{
			$this->db->count_all_results('tblproduct');
			$this->db->from('tblproduct');
			$this->db->where('prodStatus','Active');
			$this->db->where('status',1);
			return $query=$this->db->count_all_results();
		}

		function unsoldProducts($id)
		{
			$this->db->select();
			$this->db->from('tblproduct p');
			$this->db->join('tblcategory c', 'c.catID = p.catID');
			$this->db->where('p.prodStatus','Active');
			$this->db->where('p.status',1);
			$query=$this->db->get();
			return $query->result();
		}

		function soldProducts($id)
		{
			$this->db->select();
			$this->db->from('tblproduct p');
			$this->db->join('tblcategory c', 'c.catID = p.catID');
			$this->db->where('p.prodStatus','Inactive');
			$this->db->where('p.status',1);
			$query=$this->db->get();
			return $query->result();
		}

		function countSoldProducts($id)
		{
			$this->db->count_all_results('tblproduct');
			$this->db->from('tblproduct');
			$this->db->where('prodStatus','Inactive');
			$this->db->where('status',1);
			return $query=$this->db->count_all_results();
		}
	}
?>
