<?php
	class CategoryModel extends CI_Model
	{
		function __construct()
		{
			parent::__construct();
		}

		function addCategory($data)
		{
			$this->db->insert('tblcategory',$data);
			$row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		function viewCategory()
		{
			$this->db->select('catID,catName,catDescription,catImage,status');
			$this->db->from('tblcategory');
			$query=$this->db->get();
			return $query->result();
		}

		function editCategory($id)
		{
			$this->db->select();
			$this->db->from('tblcategory');
			$this->db->where('catID', $id);
			$query=$this->db->get();
			return $query->result();
		}

		function updateCategory($data,$id)
		{
			$this->db->set($data);
		    $this->db->where("catID", $id);
		    $this->db->update("tblcategory");
		    $row = $this->db->affected_rows();
			if($row)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
    }
?>