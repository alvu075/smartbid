<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bid extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('BidModel');
	}
	
	public function newBid()
	{
		$bidderID = $this->session->userdata('bidderID');
		$now = new DateTime();
		$now->setTimezone(new DateTimezone('Asia/Karachi'));
		$data=array(
			'bidderID'=>$bidderID,
			'prodID'=>$this->input->post('productID'),
			'bidAmount'=>$this->input->post('bidAmount'),
			'date'=>$now->format('Y-m-d'),
			'time'=>$now->format('H:i:s')
		);
		$answer=$this->BidModel->newBid($data);
		$this->session->set_flashdata('success','Bid submited successfully...!');
		redirect(base_url(). 'Customer');
	}
}
?>