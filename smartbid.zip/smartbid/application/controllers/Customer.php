<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('CustomerModel');
	}


	public function index()
	{
		$data['categories']=$this->CustomerModel->getCategories();
		$data['products']=$this->CustomerModel->getproducts();
		$data['sellerFeedback']=$this->CustomerModel->getSellerFeedback();
		$data['bidderFeedback']=$this->CustomerModel->getBidderFeedback();
		$this->load->view('customer/index',$data);
	}

	public function verifylogin()
	{
		$this->load->view('customer/login');
	}


    public function bidderSignUp()
	{
		$this->load->view('customer/bidderSignUp');
	}

	public function sellerSignUp()
	{
		$this->load->view('customer/sellerSignUp');
	}

	public function bidderlogin()
	{
		$this->load->view('customer/bidderlogin');
	}
	


	public function verifyBidderLogin()
	{
		$phone=$this->input->post('txtphone');
		$password=md5($this->input->post('txtpassword'));
		$bidderID=$this->CustomerModel->verifybidderLogin($phone,$password);
		if($bidderID)
		{
			$this->session->set_userdata('bidderID', $bidderID);
			$this->session->set_userdata('bidderEmail_Phone', $phone);
			$this->session->set_flashdata('success','Login successfull...!');
			redirect(base_url(). 'Customer');
		}
		else
		{
			$this->session->set_flashdata('error','Invalid email or password...!');
			redirect(base_url(). 'customer');
		}
	}

	public function addBidder()
	{
		if($this->input->post('txtpassword')===$this->input->post('txtconfirmpassword'))
		{
			$config['upload_path'] = './assets/images/customers/';
			$config['file_ext_tolower'] = TRUE;
	        $config['allowed_types'] = 'jpg|png|jpeg';
	        $config['max_size'] = 204800;
	       
	       // $config['max_width'] = 768;
	       // $config['max_height'] = 1024;

	        $this->load->library('upload', $config);        
	        if ( ! $this->upload->do_upload('bidderImage'))
	        {
	        	$error = array('error' => $this->upload->display_errors("<h4 class='text-danger text-canter'>","</h4>"));
				$this->load->view('customer/bidderSignUp', $error);
			}
	        else
	        {
	        	$codeStatus = rand();
	        	$bidderEmail = $this->input->post('txtemail');
	        	$data = array('upload_data' => $this->upload->data());
				$data=array(
					'bidderName'=>$this->input->post('txtname'),
					'bidderPhone'=>$this->input->post('txtphone'),
					'bidderPassword'=>md5($this->input->post('txtpassword')),
					'bidderCity'=>$this->input->post('txtcity'),
					'bidderAddress'=>$this->input->post('txtaddress'),
					'bidderGender'=>$this->input->post('gender'),
					'bidderEmail'=>$this->input->post('txtemail'),
					'bidderPhoto'=>$this->upload->data('file_name'),
					'emailStatus'=>0,
					'status'=>0,
					'codeStatus'=>$codeStatus
				);
				$answer=$this->CustomerModel->addBidder($data,$bidderEmail);
				if($answer)
				{
					$subject = 'Email Verification';

					//Message
					$message ="
					<html>
					<head>
					</head>
					<body>
						<h1>Dear customer.</h1>
						<h2>Congratulations! Your account is created.</h2>
						<p>The next step is to verify email account.</p>
						<p>Please click on the bellow button to verify email account.</p>
						<form method='POST' action='<?=base_url();?>customer/bidderemailVerified'>
							<input type='hidden' name='txtemail' value='$bidderEmail'>
							<input type='hidden' name='code' value='$codeStatus'>
							<button class='btn' style='background-color: #9bbf4c; color:white; border:none; padding: 4px 28px 4px 28px;font-size: 21px; cursor: pointer;'>Verify Email</button>
						</form><br>
			        	<h3>Regards:</h3>
			        	<h3>smartBID</h3>
			        </body>
			        </html>
			        ";
			        $from="smartBID";
			        // To send HTML mail, the Content-type header must be set
			        $headers[] = 'MIME-Version: 1.0';
			        $headers[] = 'Content-type: text/html; charset=iso-8859-1';
			        // Additional headers
			        $headers[] = "From: $from";
			        $headers[] = 'Cc: smartBID';
			        $headers[] = 'Bcc: smartBID';

			        // Mail it
					if(mail($bidderEmail, $subject, $message, implode("\r\n", $headers)))
					{
						$this->session->set_flashdata('success','Registration successfull...!');
						redirect(base_url(). 'Customer/successfullBidderSignUp');
					}
				}
				else
				{
					$this->session->set_flashdata('error','This Email is already Registered.Please login to your Account...!');
					redirect(base_url(). 'Customer/bidderSignUp');
				}
			}
		}
		else
		{
			$this->session->set_flashdata('error','Password and confirm password not matched...!');
			$this->load->view('customer/bidderSignUp');
		}
	}

	public function sellerLogin()
	{
		$this->load->view('customer/sellerLogin');
	}

	public function verifysellerLogin()
	{
		$phone=$this->input->post('txtphone');
		$password=md5($this->input->post('txtpassword'));
		$sellerID=$this->CustomerModel->verifysellerLogin($phone,$password);
		if($sellerID)
		{
			$this->session->set_userdata('sellerID', $sellerID);
			$this->session->set_flashdata('success','Login successfull...!');
			redirect(base_url(). 'Customer');
		}
		else
		{
			$this->session->set_flashdata('error','Invalid email or password...!');
			redirect(base_url(). 'Customer/sellerLogin');
		}
	}

	public function addSeller()
	{
		if($this->input->post('txtpassword')===$this->input->post('txtconfirmpassword'))
		{
			$config['upload_path'] = './assets/images/customers/';
			$config['file_ext_tolower'] = TRUE;
	        $config['allowed_types'] = 'jpg|png|jpeg';
	        $config['max_size'] = 204800;
	       
	       // $config['max_width'] = 768;
	       // $config['max_height'] = 1024;

	        $this->load->library('upload', $config);        
	        if ( ! $this->upload->do_upload('sellerImage'))
	        {
	        	$error = array('error' => $this->upload->display_errors("<h4 class='text-danger text-canter'>","</h4>"));
				$this->load->view('customer/sellerSignUp', $error);
			}
	        else
	        {
	        	$codeStatus = rand();
	        	$sellerEmail = $this->input->post('txtemail');
	        	$data = array('upload_data' => $this->upload->data());
				$data=array(
					'sellerName'=>$this->input->post('txtname'),
					'sellerPhone'=>$this->input->post('txtphone'),
					'sellerPassword'=>md5($this->input->post('txtpassword')),
					'sellerCity'=>$this->input->post('txtcity'),
					'sellerAddress'=>$this->input->post('txtaddress'),
					'sellerGender'=>$this->input->post('gender'),
					'sellerEmail'=>$this->input->post('txtemail'),
					'sellerPhoto'=>$this->upload->data('file_name'),
					'emailStatus'=>0,
					'status'=>0,
					'codeStatus'=>$codeStatus
				);
				$answer=$this->CustomerModel->addSeller($data,$sellerEmail);
				if($answer)
				{
					$subject = 'Email Verification';

					//Message
					$message ="
					<html>
					<head>
					</head>
					<body>
						<h1>Dear customer.</h1>
						<h2>Congratulations! Your account is created.</h2>
						<p>The next step is to verify email account.</p>
						<p>Please click on the bellow button to verify email account.</p>
						<form method='POST' action='<?=base_url();?>customer/selleremailVerified'>
							<input type='hidden' name='txtemail' value='$sellerEmail'>
							<input type='hidden' name='code' value='$codeStatus'>
							<button class='btn' style='background-color: #9bbf4c; color:white; border:none; padding: 4px 28px 4px 28px;font-size: 21px; cursor: pointer;'>Verify Email</button>
						</form><br>
			        	<h3>Regards:</h3>
			        	<h3>smartBID</h3>
			        </body>
			        </html>
			        ";
			        $from="smartBID";
			        // To send HTML mail, the Content-type header must be set
			        $headers[] = 'MIME-Version: 1.0';
			        $headers[] = 'Content-type: text/html; charset=iso-8859-1';
			        // Additional headers
			        $headers[] = "From: $from";
			        $headers[] = 'Cc: smartBID';
			        $headers[] = 'Bcc: smartBID';

			        // Mail it
					if(mail($sellerEmail, $subject, $message, implode("\r\n", $headers)))
					{
						$this->session->set_flashdata('success','Registration successfull...!');
						redirect(base_url(). 'Customer/successfullSellerSignUp');
					}
				}
				else
				{
					$this->session->set_flashdata('error','This Email is already Registered.Please login to your Account...!');
					redirect(base_url(). 'Customer/sellerSignUp');
				}
			}
		}
		else
		{
			$this->session->set_flashdata('error','Password and confirm password not matched...!');
			$this->load->view('customer/sellerSignUp');
		}
	}
	public function viewproducts()
	{
		$id = $this->uri->segment(3);
		$data['products']=$this->CustomerModel->getProductsByID($id);
		$this->load->view('customer/products',$data);
	}

	public function viewproductsdetail()
	{
		$id = $this->uri->segment(3);
		$data['productsdetails']=$this->CustomerModel->getProductsdetailByID($id);
		$data['bidsdetail']=$this->CustomerModel->bidsdetails($id);
		$this->load->view('customer/productsDetail',$data);
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url(). 'Customer');
	}

	public function addProduct ()
	{
		$data['categories']=$this->CustomerModel->getCategories();
		$this->load->view('customer/addProduct',$data);
	}

	public function addNewProduct()
	{
		$config['upload_path'] = './assets/images/ProductsImage/';
		$config['file_ext_tolower'] = TRUE;
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = 204800;
        $this->load->library('upload', $config);        
        if ( ! $this->upload->do_upload('prodimage'))
        {
        	$error = array('error' => $this->upload->display_errors("<h4 class='text-danger text-canter'>","</h4>"));
			$this->load->view('customer/addProduct', $error);
		}
        else
        {
        	$sellerID = $this->session->userdata('sellerID');
        	$data = array('upload_data' => $this->upload->data());	
			$data=array(
				'prodName'=>$this->input->post('txtprodname'),
				'catID'=>$this->input->post('ddCategory'),
				'sellerID'=>$sellerID,
				'prodPrice'=>$this->input->post('txtprodprice'),
				'prodQuantity'=>$this->input->post('txtprodquantity'),
				'prodStartDate'=>$this->input->post('txtstartdate'),
				'prodEndDate'=>$this->input->post('txtenddate'),
				'prodDescription'=>$this->input->post('proddes'),
				'prodImage'=>$this->upload->data('file_name'),
				'prodStatus'=>'Active',
				'status'=>0
			);
			$answer=$this->CustomerModel->addProduct($data);
			if($answer)
			{
				$this->session->set_flashdata('success','Product added successfuly...!');
				redirect(base_url(). 'Customer');
			}
			else
			{
				$this->session->set_flashdata('error','Product not added...!');
				redirect(base_url(). 'Customer');
			}
		}
	}

	public function bidderForgetPassword()
	{
		$this->load->view('customer/bidderForgetPassword');
	}

	public function bidderPasswordResetForm()
	{
		$this->load->view('customer/bidderResetPassword');
	}

	public function bidderResetPassword()
	{
		$email = $this->input->post('txtemail');
		$code=md5(rand());
		$data=array(
			'codeStatus'=>$code
		);
		$answer=$this->CustomerModel->bidderResetPassword($email,$data);
		if($answer)
		{
			$subject = 'SmartBID Reset Password';
	        $message =" 
	        <html>
	        	<head>
	          		<title>Smart Bid</title>
	          		<style>

	          			#btn-primary
	          			{
	              			background: #30a5ff;
			              	border: 0;
			              	padding: 2% 5%;
			              	color: #fff;
			              	border-color: #30a5ff;
			              	transition: 0.4s;
			              	border-radius: 0;
			              	cursor: pointer;
			          	}
			            #btn:hover,#btn:active
			            {
			                outline: none !important;
			                box-shadow: none;
			                background: #13a456;
			            }
			        </style>
	        	</head>
	        	<body>
			        <h2>SmartBID</h2>
			        <h3>Hey Dear,</h3>
			        <p>To reset your password, Please click on the bellow button.</p>
			        <form method='post' action='<?=base_url();?>customer/bidderPasswordResetForm'>
			       		<input type='hidden' name='email' value='$email'>
			       		<input type='hidden' name='code' value='$code'>
			       		<input type='submit' value='Reset Password' id='btn'>
			        </form>
			    </body>
	        </html>";
	        
	        // To send HTML mail, the Content-type header must be set
	        $headers[] = 'MIME-Version: 1.0';
	        $headers[] = 'Content-type: text/html; charset=iso-8859-1';
	        
	        // Additional headers
	        $headers[] = 'To: $email';
	        $headers[] = 'From:SmartBID';
	        $headers[] = 'Cc:SmartBID';
	        $headers[] = 'Bcc:SmartBID';
	        
	        // Mail it
	        if(mail($email, $subject, $message, implode("\r\n", $headers)))
	        {
	        	$this->session->set_flashdata('success','Email Sent Successfuly...!');
				redirect(base_url(). 'Customer/bidderForgetPassword');
	        }
	        else
	        {
	        	$this->session->set_flashdata('error','Email Not Sent...!');
				redirect(base_url(). 'Customer/bidderForgetPassword');
	        }
	    }
	    else
	    {
	    	$this->session->set_flashdata('warning','Email is not registered...!');
			redirect(base_url(). 'customer/bidderForgetPassword');
	    }
	}

	public function bidderPasswordReset()
	{
		if($this->input->post('txtNewPassword') === $this->input->post('txtConfirmPassword'))
		{
			$email = $this->input->post('txtemail');
			$code = $this->input->post('txtcode');
			$data=array(
				'bidderPassword'=>md5($this->input->post('txtNewPassword')),
				'codeStatus'=>0
			);
			$passwordReset = $this->CustomerModel->bidderPasswordReset($email,$code,$data);
			if($passwordReset)
			{
				$this->session->set_flashdata('success','Password has been changed successfuly...!');
				redirect(base_url(). 'Customer');
			}
			else
			{
				$this->session->set_flashdata('error','Password not changed...!');
				redirect(base_url(). 'Customer/bidderPasswordResetForm');
			}
		}
		else
		{
			$this->session->set_flashdata('warning','New password and confirm password not matched...!');
			redirect(base_url(). 'Customer/bidderPasswordResetForm');
		}
	}

	public function sellerForgetPassword()
	{
		$this->load->view('customer/sellerForgetPassword');
	}

	public function sellerPasswordResetForm()
	{
		$this->load->view('customer/sellerResetPassword');
	}

	public function sellerResetPassword()
	{
		$email = $this->input->post('txtemail');
		$code=md5(rand());
		$data=array(
			'codeStatus'=>$code
		);
		$answer=$this->CustomerModel->sellerResetPassword($email,$data);
		if($answer)
		{
			$subject = 'SmartBID Reset Password';
	        $message =" 
	        <html>
	        	<head>
	          		<title>Smart Bid</title>
	          		<style>
	          			#btn
	          			{
	              			background: #18d26e;
			              	border: 0;
			              	padding: 2% 5%;
			              	color: #fff;
			              	transition: 0.4s;
			              	border-radius: 0;
			              	cursor: pointer;
			          	}
			            #btn:hover,#btn:active
			            {
			                outline: none !important;
			                box-shadow: none;
			                background: #13a456;
			            }
			        </style>
	        	</head>
	        	<body>
			        <h2>SmartBID</h2>
			        <h3>Hey Dear,</h3>
			        <p>To reset your password, Please click on the bellow button.</p>
			        <form method='post' action='<?=base_url();?>customer/sellerPasswordResetForm'>
			       		<input type='hidden' name='email' value='$email'>
			       		<input type='hidden' name='code' value='$code'>
			       		<input type='submit' value='Reset Password' id='btn'>
			        </form>
			    </body>
	        </html>";
	        
	        // To send HTML mail, the Content-type header must be set
	        $headers[] = 'MIME-Version: 1.0';
	        $headers[] = 'Content-type: text/html; charset=iso-8859-1';
	        
	        // Additional headers
	        $headers[] = 'To: $email';
	        $headers[] = 'From:SmartBID';
	        $headers[] = 'Cc:SmartBID';
	        $headers[] = 'Bcc:SmartBID';
	        
	        // Mail it
	        if(mail($email, $subject, $message, implode("\r\n", $headers)))
	        {
	        	$this->session->set_flashdata('success','Email Sent Successfuly...!');
				redirect(base_url(). 'Customer/sellerForgetPassword');
	        }
	        else
	        {
	        	$this->session->set_flashdata('error','Email Not Sent...!');
				redirect(base_url(). 'Customer/sellerForgetPassword');
	        }
	    }
	    else
	    {
	    	$this->session->set_flashdata('warning','Email is not registered...!');
			redirect(base_url(). 'customer/sellerForgetPassword');
	    }
	}

	public function sellerPasswordReset()
	{
		if($this->input->post('txtNewPassword') === $this->input->post('txtConfirmPassword'))
		{
			$email = $this->input->post('txtemail');
			$code = $this->input->post('txtcode');
			$data=array(
				'sellerPassword'=>md5($this->input->post('txtNewPassword')),
				'codeStatus'=>0
			);
			$passwordReset = $this->CustomerModel->sellerPasswordReset($email,$code,$data);
			if($passwordReset)
			{
				$this->session->set_flashdata('success','Password has been changed successfuly...!');
				redirect(base_url(). 'Customer');
			}
			else
			{
				$this->session->set_flashdata('error','Password not changed...!');
				redirect(base_url(). 'Customer/sellerPasswordResetForm');
			}
		}
		else
		{
			$this->session->set_flashdata('warning','New password and confirm password not matched...!');
			redirect(base_url(). 'Customer/sellerPasswordResetForm');
		}
	}

	public function profile()
	{
		$this->load->view('customer/profile');
	}

	public function updatePicture()
	{
		$config['upload_path'] = './assets/images/customers/';
		$config['file_ext_tolower'] = TRUE;
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = 204800;
       
       // $config['max_width'] = 768;
       // $config['max_height'] = 1024;

        $this->load->library('upload', $config);        
        if ( ! $this->upload->do_upload('customerImage'))
        {
        	$error = array('error' => $this->upload->display_errors("<h4 class='text-danger text-canter'>","</h4>"));
			$this->load->view('customer/profile', $error);
		}
        else
        {
        	if($this->session->userdata('bidderID'))
        	{
            	$id = $this->session->userdata('bidderID');
        		$data = array('upload_data' => $this->upload->data());
	        	$file_name = $this->upload->data('file_name');
				$customerDP = $this->CustomerModel->bidderUpdatePicture($id, $file_name);
				if($customerDP)
				{
					$this->session->set_flashdata('success','Profile picture updated...!');
					redirect(base_url(). 'Customer/profile');
				}
				else
				{
					$this->session->set_flashdata('error','Profile picture not updated...!');
					redirect(base_url(). 'Customer/profile');
				}
        	}
        	else
        	{
        		$id = $this->session->userdata('sellerID');
        		$data = array('upload_data' => $this->upload->data());
	        	$file_name = $this->upload->data('file_name');
				$customerDP = $this->CustomerModel->sellerUpdatePicture($id, $file_name);
				if($customerDP)
				{
					$this->session->set_flashdata('success','Profile picture updated...!');
					redirect(base_url(). 'Customer/profile');
				}
				else
				{
					$this->session->set_flashdata('error','Profile picture not updated...!');
					redirect(base_url(). 'Customer/profile');
				}
        	}
		}
	}

	public function updateProfile()
	{
		if($this->session->userdata('sellerID'))
		{
			$data=array(
				'sellerName'=>$this->input->post('txtname'),
				'sellerPhone'=>$this->input->post('txtphoneNumber'),
				'sellerEmail'=>$this->input->post('txtemail'),
				'sellerGender'=>$this->input->post('ddgender'),
				'sellerCity'=>$this->input->post('txtcity'),
				'sellerAddress'=>$this->input->post('txtaddress')
			);
			$id = $this->session->userdata('sellerID');
			$answer=$this->CustomerModel->sellerUpdateProfile($id,$data);
			if($answer)
			{
				$this->session->set_flashdata('success','Profile details updated successfuly...!');
				redirect(base_url(). 'Customer/profile');
			}
			else
			{
				$this->session->set_flashdata('error','Profile details not updated...!');
				redirect(base_url(). 'Customer/profile');
			}
		}
		else
		{
			$data=array(
				'bidderName'=>$this->input->post('txtname'),
				'bidderPhone'=>$this->input->post('txtphoneNumber'),
				'bidderEmail'=>$this->input->post('txtemail'),
				'bidderGender'=>$this->input->post('ddgender'),
				'bidderCity'=>$this->input->post('txtcity'),
				'bidderAddress'=>$this->input->post('txtaddress')
			);
			$id = $this->session->userdata('bidderID');
			$answer=$this->CustomerModel->bidderUpdateProfile($id,$data);
			if($answer)
			{
				$this->session->set_flashdata('success','Profile details updated successfuly...!');
				redirect(base_url(). 'Customer/profile');
			}
			else
			{
				$this->session->set_flashdata('error','Profile details not updated...!');
				redirect(base_url(). 'Customer/profile');
			}
		}
	}

	public function updatePassword()
	{
		if($this->session->userdata('sellerID'))
		{
			if($this->input->post('oldpass') === md5($this->input->post('txtoldpassword')))
			{
				if($this->input->post('txtnewpassword') === $this->input->post('txtconfirmpassword'))
				{
					$data=array(
						'sellerPassword'=>md5($this->input->post('txtnewpassword'))
					);
					$id = $this->session->userdata('sellerID');
					$updatePass = $this->CustomerModel->updatesellerPassword($id,$data);
					if($updatePass)
					{
						$this->session->set_flashdata('success','Password has been changed successfuly...!');
						redirect(base_url(). 'Customer/profile');
					}
					else
					{
						$this->session->set_flashdata('error','Password not changed...!');
						redirect(base_url(). 'Customer/profile');
					}
				}
				else
				{
					$this->session->set_flashdata('warning','New password and confirm password not matched...!');
					redirect(base_url(). 'Customer/profile');
				}
			}
			else
			{
				$this->session->set_flashdata('warning','Old password is wrong...!');
				redirect(base_url(). 'Customer/profile');
			}
		}
		else
		{
			if($this->input->post('oldpass') === md5($this->input->post('txtoldpassword')))
			{
				if($this->input->post('txtnewpassword') === $this->input->post('txtconfirmpassword'))
				{
					$data=array(
						'bidderPassword'=>md5($this->input->post('txtnewpassword'))
					);
					$id = $this->session->userdata('bidderID');
					$updatePass = $this->CustomerModel->updateBidderPassword($id,$data);
					if($updatePass)
					{
						$this->session->set_flashdata('success','Password has been changed successfuly...!');
						redirect(base_url(). 'Customer/profile');
					}
					else
					{
						$this->session->set_flashdata('error','Password not changed...!');
						redirect(base_url(). 'Customer/profile');
					}
				}
				else
				{
					$this->session->set_flashdata('warning','New password and confirm password not matched...!');
					redirect(base_url(). 'Customer/profile');
				}
			}
			else
			{
				$this->session->set_flashdata('warning','Old password is wrong...!');
				redirect(base_url(). 'Customer/profile');
			}	
		}

	}

	public function contactUs()
	{
		$name = $this->input->post('name');
		$email = $this->input->post('email');
		$subject = $this->input->post('subject');
		$message = $this->input->post('message');

	    $to = 'asadit2014@gmail.com';
	    // To send HTML mail, the Content-type header must be set
	    $headers[] = 'MIME-Version: 1.0';
	    $headers[] = 'Content-type: text/html; charset=iso-8859-1';
	        
	    // Additional headers
	    //$headers[] = 'To: $email';
	    $headers[] = 'From:$name $email';
	    $headers[] = 'Cc:smartBID';
	    $headers[] = 'Bcc:smartBID';
	        
	    // Mail it
	    if(mail($to, $subject, $message, implode("\r\n", $headers)))
	    {
	    	$this->session->set_flashdata('success','Message Sent Successfuly...!');
				redirect(base_url(). 'customer');
        }
        else
        {
        	$this->session->set_flashdata('error','Message Sending Failed...!');
				redirect(base_url(). 'customer');
        }
	}

	public function feedback()
	{
		$this->load->view('customer/feedback');
	}

	public function postFeedback()
	{
		if($this->session->userdata('bidderID') or $this->session->userdata('sellerID'))
		{
			if ($this->session->userdata('bidderID')) 
			{
				$bidderID = $this->session->userdata('bidderID');
				$now = new DateTime();
				$now->setTimezone(new DateTimezone('Asia/Karachi'));
				$data=array(
					'bidderID'=>$bidderID,
					'name'=>$this->input->post('name'),
					'feedback'=>$this->input->post('feedback'),
					'email'=>$this->input->post('email'),
					'date'=>$now->format('Y-m-d'),
					'time'=>$now->format('H:i:s')
				);
				$answer=$this->CustomerModel->postFeedback($data);
				if($answer)
				{
					$this->session->set_flashdata('success','Your feedback has been submitted...!');
					redirect(base_url(). 'Customer/feedback');
				}
				else
				{
					$this->session->set_flashdata('error','Your feedback has not been submitted. Try again...!');
					redirect(base_url(). 'Customer/feedback');
				}	
			}
			else
			{
				$sellerID = $this->session->userdata('sellerID');
				$now = new DateTime();
				$now->setTimezone(new DateTimezone('Asia/Karachi'));
				$data=array(
					'sellerID'=>$sellerID,
					'name'=>$this->input->post('name'),
					'feedback'=>$this->input->post('feedback'),
					'email'=>$this->input->post('email'),
					'date'=>$now->format('Y-m-d'),
					'time'=>$now->format('H:i:s')
				);
				$answer=$this->CustomerModel->postFeedback($data);
				if($answer)
				{
					$this->session->set_flashdata('success','Your feedback has been submitted...!');
					redirect(base_url(). 'Customer/feedback');
				}
				else
				{
					$this->session->set_flashdata('error','Your feedback has not been submitted. Try again...!');
					redirect(base_url(). 'Customer/feedback');
				}
			}	
			
		}
		else
		{
			$this->session->set_flashdata('error','Please login to your account first...!');
				redirect(base_url(). 'Customer/feedback');
		}
	}

	public function soldProducts()
	{
		$id = $this->session->userdata('sellerID');
		$data['soldProducts']=$this->CustomerModel->soldProducts($id);
		$data['countMyProducts']=$this->CustomerModel->countSoldProducts($id);
		$this->load->view('customer/soldProducts',$data);
	}

	public function unsoldProducts()
	{
		$id = $this->session->userdata('sellerID');
		$data['unsoldProducts']=$this->CustomerModel->unsoldProducts($id);
		$data['countMyProducts']=$this->CustomerModel->countUnsoldProducts($id);
		$this->load->view('customer/unsoldProducts',$data);
	}

	public function sellerProdBidDetail()
	{
		$id = $this->session->userdata('sellerID');
		$data['allBids']=$this->CustomerModel->sellerProdBidDetail($id);
		//$data['countMyProducts']=$this->CustomerModel->countUnsoldProducts($id);
		$this->load->view('customer/sellerProdBidDetail',$data);
	}

	public function editProduct()
	{
		$id = $this->uri->segment(3);
		$data['productDetails'] = $this->CustomerModel->editProduct($id);
		$data['categories']=$this->CustomerModel->getCategories();
		$this->load->view('customer/updateProduct',$data);
	}

	public function updateProduct()
	{
		if ($_FILES['prodImage']['error'] == 4)
		{
			$id = $this->uri->segment(3);
			$data=array(
				'catID'=>$this->input->post('ddCategory'),
				'prodName'=>$this->input->post('txtprodName'),
				'prodPrice'=>$this->input->post('txtprodprice'),
				'prodQuantity'=>$this->input->post('txtprodquantity'),
				'prodStartDate'=>$this->input->post('txtstartdate'),
				'prodEndDate'=>$this->input->post('txtenddate'),
				'prodDescription'=>$this->input->post('txtprodDescription'),
				'prodStatus'=>$this->input->post('ddstatus')
			);
			$answer=$this->CustomerModel->updateProduct($data,$id);
			if($answer)
			{
				$this->session->set_flashdata('success','Product updated successfuly...!');
				redirect(base_url(). 'customer/unsoldProducts');
			}
			else
			{
				$this->session->set_flashdata('error','Product not updated...!');
				redirect(base_url(). 'customer/unsoldProducts');
			}
		}
		else
		{
			$config['upload_path'] = './assets/images/ProductsImage/';
			$config['file_ext_tolower'] = TRUE;
	        $config['allowed_types'] = 'jpg|png|jpeg';
	        $config['max_size'] = 204800;
	       
	       // $config['max_width'] = 768;
	       // $config['max_height'] = 1024;

	        $this->load->library('upload', $config);        
	        if ( ! $this->upload->do_upload('prodImage'))
	        {
	        	$error = array('error' => $this->upload->display_errors("<p class='text-danger'>","</p>"));
	        	$this->load->view('customer/updateProduct', $error);
			}
	        else
	        {
	        	$id = $this->uri->segment(3);
	        	$data = array('upload_data' => $this->upload->data());
				$data=array(
					'catID'=>$this->input->post('ddCategory'),
					'prodName'=>$this->input->post('txtprodName'),
					'prodPrice'=>$this->input->post('txtprodprice'),
					'prodQuantity'=>$this->input->post('txtprodquantity'),
					'prodStartDate'=>$this->input->post('txtstartdate'),
					'prodEndDate'=>$this->input->post('txtenddate'),
					'prodDescription'=>$this->input->post('txtprodDescription'),
					'prodStatus'=>$this->input->post('ddstatus'),
					'prodImage'=>$this->upload->data('file_name')
				);
				$answer=$this->CustomerModel->updateProduct($data,$id);
				if($answer)
				{
					$this->session->set_flashdata('success','Product updated successfuly...!');
					redirect(base_url(). 'customer/unsoldProducts');
				}
				else
				{
					$this->session->set_flashdata('error','Product not updated...!');
					redirect(base_url(). 'customer/unsoldProducts');	
				}
			}
		}
	}
	
	public function successfullSellerSignUp()
	{
		$this->load->view('customer/successfullSellerSignUp');
	}

	public function successfullBidderSignUp()
	{
		$this->load->view('customer/successfullBidderSignUp');
	}

	public function bidderemailVerified()
	{
		$bidderEmail = $this->input->post('txtemail');
		$answer=$this->CustomerModel->bidderemailVerified($bidderEmail);
		$this->load->view('customer/bidderemailVerified');
	}

	public function selleremailVerified()
	{
		$sellerEmail = $this->input->post('txtemail');
		$answer=$this->CustomerModel->selleremailVerified($sellerEmail);
		$this->load->view('customer/selleremailVerified');
	}
	
}
