<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('AdminModel');
	}

	public function index()
	{
		$this->load->view('admin/login');
	}

	public function login()
	{
		$email=$this->input->post('txtemail');
		$password=md5($this->input->post('txtpassword'));
		$userID=$this->AdminModel->login($email,$password);
		if($userID)
		{
			foreach ($userID as $row) 
			{
				$id = $row->userID;
				$role = $row->role;
			}
			$session_data = array( 'userid' => $id, 'role' => $role);
			$this->session->set_userdata($session_data);
			redirect(base_url(). 'Admin/dashboard');
		}
		else
		{
			$this->session->set_flashdata('error','Invalid email or password...!');
			redirect(base_url(). 'Admin');
		}
	}

	public function dashboard()
	{
		$data['categories']=$this->AdminModel->allCategories();
		$data['products']=$this->AdminModel->allProducts();
		$data['seller']=$this->AdminModel->allSeller();
		$data['bidder']=$this->AdminModel->allBidder();
		$this->load->view('admin/index',$data);
	}

	public function adduser()
	{
		$this->load->view('admin/addUser');
	}

	public function userRegistration()
	{
		$config['upload_path'] = './assets/images/adminProfile/';
		$config['file_ext_tolower'] = TRUE;
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = 204800;
       
       // $config['max_width'] = 768;
       // $config['max_height'] = 1024;

        $this->load->library('upload', $config);        
        if ( ! $this->upload->do_upload('userimage'))
        {
        	$error = array('error' => $this->upload->display_errors("<h4 class='text-danger text-canter'>","</h4>"));
			$this->load->view('admin/addUser', $error);
		}
        else
        {
        	$data = array('upload_data' => $this->upload->data());
			$data=array(
				'userName'=>$this->input->post('txtname'),
				'userPhone'=>$this->input->post('txtphone'),
				'userEmail'=>$this->input->post('txtemail'),
				'userPassword'=>md5($this->input->post('txtpassword')),
				'role'=>$this->input->post('urole'),
				'status'=>$this->input->post('ustatus'),
				'userImage'=>$this->upload->data('file_name')
			);
			$answer=$this->AdminModel->userRegistration($data);
			if($answer)
			{
				$this->session->set_flashdata('success','User added successfuly...!');
				$this->load->view('admin/addUser');
			}
			else
			{
				$this->session->set_flashdata('error','User not added...!');
				$this->load->view('admin/addUser');
			}
		}
	}

	public function viewUser()
	{
		$data['users']=$this->AdminModel->viewUser();
		$this->load->view('admin/viewUser',$data);
	}

	public function editUser()
	{
		$id = $this->uri->segment(3);
		$answer['userDetails'] = $this->AdminModel->editUser($id);
		$this->load->view('admin/updateUser',$answer);
	}

	public function updateUser()
	{
		$id = $this->uri->segment(3);
		$data=array(
			'status'=>$this->input->post('ustatus')		
		);
	    $answer=$this->AdminModel->updateUser($data,$id);
		if($answer)
		{
			$this->session->set_flashdata('success','User details updated successfuly...!');
			redirect(base_url(). 'Admin/viewUser');
		}
		else
		{
			$this->session->set_flashdata('error','User details not updated...!');
			redirect(base_url(). 'Admin/viewUser');
		}
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url(). 'Admin');
	}

	public function updatePicture()
	{
		$config['upload_path'] = './assets/images/adminProfile/';
		$config['file_ext_tolower'] = TRUE;
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = 204800;
       
       // $config['max_width'] = 768;
       // $config['max_height'] = 1024;

        $this->load->library('upload', $config);        
        if ( ! $this->upload->do_upload('userImage'))
        {
        	$error = array('error' => $this->upload->display_errors("<h4 class='text-danger text-canter'>","</h4>"));
			$this->load->view('Admin/profile', $error);
		}
        else
        {
            $id = $this->session->userdata('userid');
        	$data = array('upload_data' => $this->upload->data());
        	$file_name = $this->upload->data('file_name');
			$userDP = $this->AdminModel->updatePicture($id, $file_name);
			if($userDP)
			{
				$this->session->set_flashdata('success','Profile picture updated...!');
				$this->load->view('admin/profile');
			}
			else
			{
				$this->session->set_flashdata('error','Profile picture not updated...!');
				$this->load->view('admin/profile');
			}
		}
	}

	public function updateProfileDetails()
	{
		$data=array(
			'userName'=>$this->input->post('txtName'),
			'userPhone'=>$this->input->post('txtphoneNumber'),
			'userEmail'=>$this->input->post('txtemail')
		);
		$id = $this->session->userdata('userid');
		$answer=$this->AdminModel->updateProfileDetails($id,$data);
		if($answer)
		{
			$this->session->set_flashdata('success','Profile details updated successfuly...!');
			$this->load->view('admin/profile');
		}
		else
		{
			$this->session->set_flashdata('error','Profile details not updated...!');
			$this->load->view('admin/profile');
		}
	}

	public function profile()
	{
		$this->load->view('admin/profile');
	}

	public function changePassword()
	{
		$this->load->view('admin/changePassword');
	}

	public function updatePassword()
	{
		$id = $this->session->userdata('userid');
		$currentPass = $this->AdminModel->getCurrentPassword($id);
		if($currentPass === md5($this->input->post('txtCurrentPass')))
		{
			if($this->input->post('txtNewPass') === $this->input->post('txtConfirmPass'))
			{
				$data=array(
					'userPassword'=>md5($this->input->post('txtNewPass'))
				);
				$id = $this->session->userdata('userid');
				$updatePass = $this->AdminModel->updatePassword($id,$data);
				if($updatePass)
				{
					$this->session->set_flashdata('success','Password has been changed successfuly...!');
					$this->load->view('admin/changePassword');
				}
				else
				{
					$this->session->set_flashdata('error','Password not changed...!');
					$this->load->view('admin/changePassword');
				}
			}
			else
			{
				$this->session->set_flashdata('warning','New password and confirm password not matched...!');
				$this->load->view('admin/changePassword');
			}
		}
		else
		{
			$this->session->set_flashdata('warning','Old password is wrong...!');
			$this->load->view('admin/changePassword');
		}	
	}
}
?>
