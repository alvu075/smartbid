<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

	
	function __construct()
	{
		parent::__construct();
		$this->load->model('ProductModel');
	}
	public function index()
	{
		$data['categories']=$this->ProductModel->allCategories();
		$data['seller']=$this->ProductModel->allSeller();
		
		$this->load->view('admin/addProduct',$data);
	}

	public function addProduct()
	{
		$config['upload_path'] = './assets/images/ProductsImage/';
		$config['file_ext_tolower'] = TRUE;
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = 204800;
        $this->load->library('upload', $config);        
        if ( ! $this->upload->do_upload('prodimage'))
        {
        	$error = array('error' => $this->upload->display_errors("<h4 class='text-danger text-canter'>","</h4>"));
			$this->load->view('admin/addProduct', $error);
		}
        else
        {
        	$data = array('upload_data' => $this->upload->data());	
			$data=array(
			'prodName'=>$this->input->post('txtprodname'),
			'catID'=>$this->input->post('ddCategory'),
			'sellerID'=>$this->input->post('ddseller'),
			'prodPrice'=>$this->input->post('txtprodprice'),
			'prodQuantity'=>$this->input->post('txtprodquantity'),
			'prodStatus'=>$this->input->post('prostatus'),
			'prodStartDate'=>$this->input->post('txtstartdate'),
			'prodEndDate'=>$this->input->post('txtenddate'),
			'prodDescription'=>$this->input->post('proddes'),
			'prodImage'=>$this->upload->data('file_name')
			);
			$answer=$this->ProductModel->addProduct($data);
			if($answer)
			{
				$this->session->set_flashdata('success','Product added successfuly...!');
				redirect(base_url(). 'Product');
			}
			else
			{
				$this->session->set_flashdata('error','Product not added...!');
				redirect(base_url(). 'Product');
			}
		}
	}

	public function newProducts()
	{
		$data['newProducts']=$this->ProductModel->newProducts();
		$this->load->view('admin/newProducts',$data);
	}	

	public function viewProduct()
	{
		$data['products']=$this->ProductModel->viewProduct();
		$this->load->view('admin/viewProduct',$data);
	}	

	public function editProduct()
	{
		$id = $this->uri->segment(3);
		$data['productDetails'] = $this->ProductModel->editProduct($id);
		$data['categories']=$this->ProductModel->allCategories();
		$this->load->view('admin/updateProduct',$data);
	}

	public function editNewProduct()
	{
		$id = $this->uri->segment(3);
		$data = $this->ProductModel->editNewProduct($id);
		if($data)
			{
				$this->session->set_flashdata('success','Product Activated...!');
				redirect(base_url(). 'Product/newProducts');
			}
			else
			{
				$this->session->set_flashdata('error','Product Not Activated...!');
				redirect(base_url(). 'Product/newProducts');
			}
	}

	public function updateProduct()
	{
		if ($_FILES['prodImage']['error'] == 4)
		{
			$id = $this->uri->segment(3);
			$data=array(
				'catID'=>$this->input->post('ddCategory'),
				'prodName'=>$this->input->post('txtprodName'),
				'prodPrice'=>$this->input->post('txtprodprice'),
				'prodQuantity'=>$this->input->post('txtprodquantity'),
				'prodStartDate'=>$this->input->post('txtstartdate'),
				'prodEndDate'=>$this->input->post('txtenddate'),
				'prodDescription'=>$this->input->post('txtprodDescription'),
				'prodStatus'=>$this->input->post('ddstatus')
			);
			$answer=$this->ProductModel->updateProduct($data,$id);
			if($answer)
			{
				$this->session->set_flashdata('success','Product updated successfuly...!');
				redirect(base_url(). 'Product/viewProduct');
			}
			else
			{
				$this->session->set_flashdata('error','Product not updated...!');
				redirect(base_url(). 'Product/viewProduct');
			}
		}
		else
		{
			$config['upload_path'] = './assets/images/ProductsImage/';
			$config['file_ext_tolower'] = TRUE;
	        $config['allowed_types'] = 'jpg|png|jpeg';
	        $config['max_size'] = 204800;
	       
	       // $config['max_width'] = 768;
	       // $config['max_height'] = 1024;

	        $this->load->library('upload', $config);        
	        if ( ! $this->upload->do_upload('prodImage'))
	        {
	        	$error = array('error' => $this->upload->display_errors("<p class='text-danger'>","</p>"));
	        	$this->load->view('admin/updateProduct', $error);
			}
	        else
	        {
	        	$id = $this->uri->segment(3);
	        	$data = array('upload_data' => $this->upload->data());
				$data=array(
					'catID'=>$this->input->post('ddCategory'),
					'prodName'=>$this->input->post('txtprodName'),
					'prodPrice'=>$this->input->post('txtprodprice'),
					'prodQuantity'=>$this->input->post('txtprodquantity'),
					'prodStartDate'=>$this->input->post('txtstartdate'),
					'prodEndDate'=>$this->input->post('txtenddate'),
					'prodDescription'=>$this->input->post('txtprodDescription'),
					'prodStatus'=>$this->input->post('ddstatus'),
					'prodImage'=>$this->upload->data('file_name')
				);
				$answer=$this->ProductModel->updateProduct($data,$id);
				if($answer)
				{
					$this->session->set_flashdata('success','Product updated successfuly...!');
					redirect(base_url(). 'Product/viewProduct');
				}
				else
				{
					$this->session->set_flashdata('error','Product not updated...!');
					redirect(base_url(). 'Product/viewProduct');	
				}
			}
		}
	}	

	public function unsoldProducts()
	{
		$id = $this->session->userdata('sellerID');
		$data['unsoldProducts']=$this->ProductModel->unsoldProducts($id);
		$data['countMyProducts']=$this->ProductModel->countUnsoldProducts($id);
		$this->load->view('admin/unsoldProducts',$data);
	}	

	public function soldProducts()
	{
		$id = $this->session->userdata('sellerID');
		$data['soldProducts']=$this->ProductModel->soldProducts($id);
		$data['countMyProducts']=$this->ProductModel->countSoldProducts($id);
		$this->load->view('admin/soldProducts',$data);
	}
}
?>	