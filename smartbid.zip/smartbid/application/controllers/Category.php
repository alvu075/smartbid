<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('CategoryModel');
	}
	
	public function index()
	{
		$this->load->view('admin/addCategory');
	}

	public function addCategory()
	{
		$config['upload_path'] = './assets/images/CategoryImage/';
		$config['file_ext_tolower'] = TRUE;
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = 204800;
        $this->load->library('upload', $config);        
        if ( ! $this->upload->do_upload('catimage'))
        {
        	$error = array('error' => $this->upload->display_errors("<h4 class='text-danger text-canter'>","</h4>"));
			$this->load->view('admin/addCategory', $error);
		}
        else
        {
        	$data = array('upload_data' => $this->upload->data());	
			$data=array(
			'catName'=>$this->input->post('txtcatname'),
			'catDescription'=>$this->input->post('catdes'),
			'status'=>$this->input->post('catstatus'),
			'catImage'=>$this->upload->data('file_name')
			);
			$answer=$this->CategoryModel->addCategory($data);
			if($answer)
			{
				$this->session->set_flashdata('success','Category added successfuly...!');
				redirect(base_url(). 'Category');
			}
			else
			{
				$this->session->set_flashdata('error','Category not added...!');
				redirect(base_url(). 'Category');
			}
		}
	}

	public function viewCategory()
	{
		$data['categories']=$this->CategoryModel->viewCategory();
		$this->load->view('admin/viewCategory',$data);
	}	

	public function editCategory()
	{
		$id = $this->uri->segment(3);
		$answer['categoryDetails'] = $this->CategoryModel->editCategory($id);
		$this->load->view('admin/updateCategory',$answer);
	}		

	public function updateCategory()
	{
		$id = $this->uri->segment(3);
	    $data=array(
			'catName'=>$this->input->post('txtcatname'),
			'status'=>$this->input->post('catstatus'),
			);
		$answer=$this->CategoryModel->updateCategory($data,$id);
		if($answer)
		{
			$this->session->set_flashdata('success','Category updated successfuly...!');
			redirect(base_url(). 'Category/viewCategory');
		}
		else
		{
			$this->session->set_flashdata('error','Category not updated...!');
			redirect(base_url(). 'Category/viewCategory');
		}
	}
}
?>