<?php
	include 'includes/header.php';
?>	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Add Product</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Add Product</h1>
			</div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
			<div class="row">
				<div class="col-md-6 col-md-offset-3">
					<h3 class="box-title text-center">Add New Product</h3>
					<?php 
            echo @$error;
          ?>
				<form role="form" method="post" action="<?=base_url();?>Product/addProduct" enctype="multipart/form-data">
						<fieldset>
							<div class="form-group">
								<label>Product Name</label>
								<input class="form-control" placeholder="Enter Product Name" name="txtprodname" type="name" required>
							</div>
							<div class="form-group">
                					<label>Select Category</label>
                					<select class="form-control" name="ddCategory" required>
                  					<option value="">Select Category</option>
                 					<?php
                   					foreach ($categories as $row)
                    				{
                     				$id = $row->catID;
                      				$name = $row->catName;
                  					?>
                  					<option value="<?=$id;?>"><?=$name;?></option>
                 					<?php } ?>
               						</select>
             				</div>
             				<div class="form-group">
                					<label>Select Seller</label>
                					<select class="form-control" name="ddseller" required>
                  					<option value="">Select Seller</option>
                 					<?php
                   					foreach ($seller as $row)
                    				{
                     				$id = $row->sellerID;
                      				$name = $row->sellerName;
                  					?>
                  					<option value="<?=$id;?>"><?=$name;?></option>
                 					<?php } ?>
               						</select>
             				</div>
             				<div class="form-group">
								<label>Product Price</label>
								<input class="form-control noZero" id="price" placeholder="Enter Product Price" name="txtprodprice" type="text" onkeydown="return numberOnly(event);" required>
							</div>
							<div class="form-group">
								<label>Product Quantity</label>
								<input class="form-control noZero" placeholder="Enter Product Quantity" name="txtprodquantity" type="name" id="quantity" onkeydown="return numberOnly(event);"required>
							</div>
							<div class="form-group">
								<label>Product Status</label>
								<select class="form-control" name="prostatus" required>
									<option value=''>Select Status</option>
									<option value='Active'>Active</option>
									<option value='Inactive'>Inactive</option>
								</select>	
							</div>
							<div class="form-group">
								<label>Product Start Date</label>
								<input class="form-control" placeholder="Enter Name" name="txtstartdate" type="Date" required id="startDate" min="<?php echo date('Y-m-d');?>">
							</div>
							<div class="form-group">
								<label>Product End Date</label>
								<input class="form-control" placeholder="Enter Name" name="txtenddate" type="Date" required id="endDate" min="<?php echo date('Y-m-d');?>">
							</div>
							<div class="form-group">
									<label>Product Description</label>
									<textarea class="form-control" rows="3" name="proddes"></textarea>
							</div>
							<div class="form-group">
									<label>Product Image</label>
								    <input type="file" class="form-control" name='prodimage' required accept="Image/*">
							</div>
							<div class="text-center">
								<button class="btn btn-primary"> Add Product</button>
							</div>
							<br><br>
						</fieldset>
					</form>
				</div>
			</div><!--/.row-->
		</div>
	</div>	<!--/.main-->
<?php
	include 'includes/footer.php';
	$this->load->view('alert');
?>
<script>
  // Function to prevent writing number etc
  function alphaOnly(event) 
  {
    var key = event.keyCode;
      return ((key >= 65 && key <= 90) || key == 8 || key == 9 || key == 20 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40);
  };

  // Function to prevent writing alpha character etc
  function numberOnly(event) 
  {
    var key = event.keyCode;
      return ((key >= 48 && key <= 57) || key == 8 || key == 9 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40);
  };


$(document).ready(function(){
    $('.noZero').focusout(function()
    {
        var price = parseInt($('#price').val());
        if(price<1)
        {
           alert("Please Enter Price More Than 0");
           $('#price').val('');
            document.getElementById("price").focus();
        }

        var quantity = parseInt($('#quantity').val());
        if(quantity<1)
        {
           alert("Please Enter Quantity 1 OR more Than 1");
           $('#quantity').val('');
            document.getElementById("quantity").focus();
        }
 	});

    $('#startDate').focusout(function()
    {
 		var startDate = $('#startDate').val();
 		var currentDate = new Date().toISOString().slice(0, 10);
        if(startDate<currentDate)
        {
           alert("Previous date selection is not allowed");
           $('#startDate').val('');
        }
    });

    $('#endDate').focusout(function()
    {
    var endDate = $('#endDate').val();
    var currentDate = new Date().toISOString().slice(0, 10);
        if(endDate<currentDate)
        {
           alert("Previous date selection is not allowed");
           $('#endDate').val('');
        }
    });
});
</script>