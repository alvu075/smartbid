
<?php
	include 'includes/header.php';
?>	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Add User</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Add User</h1>
			</div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
			<div class="row">
				<div class="col-md-6 col-md-offset-3">
					<h3 class="box-title text-center">Register New User</h3>
					<?php 
            echo @$error;
          ?>
				<form role="form" method="post" action="<?=base_url();?>Admin/userRegistration" enctype="multipart/form-data">
						<fieldset>
							<div class="form-group">
								<label>Name</label>
								<input class="form-control" placeholder="Enter Name" name="txtname" type="name" onkeydown="return alphaOnly(event);" required >
							</div>
							<div class="form-group">
								<label>Phone Number</label>
								<input class="form-control" minlength="11" maxlength="11" placeholder="Enter Phone" name="txtphone" type="phone" onkeydown="return numberOnly(event);" required >
							</div>
							<div class="form-group">
								<label>Email</label>
								<input class="form-control" placeholder="Enter Email" name="txtemail" type="email" required>
							</div>
							<div class="form-group">
								<label>Password</label>
								<input class="form-control" placeholder="Enter Password" name="txtpassword" type="password" required minlength="5" >
							</div>
							<div class="form-group">
								<label>Role</label>
								<select class="form-control" name="urole" required>
									<option value=''>Select Role</option>
									<option value='Super Admin'>Super Admin</option>
									<option value='Admin'>Admin</option>
								</select>	
							</div>
							<div class="form-group">
								<label>Status</label>
								<select class="form-control" name="ustatus" required>
									<option value=''>Select Status</option>
									<option value='Active'>Active</option>
									<option value='Inactive'>Inactive</option>
								</select>	
							</div>
							<div class="form-group">
								<label>User Image</label>
								<input type="file" class="form-control" name='userimage' required accept="Image/*">
							</div>
							<div class="text-center">
								<button class="btn btn-primary"> Add User</button>
							</div>
							<br><br>
						</fieldset>
					</form>
				</div>
			</div><!--/.row-->
		</div>
	</div>	<!--/.main-->
<?php
	include 'includes/footer.php';
	$this->load->view('alert');
?>
<script>
  // Function to prevent writing number etc
  function alphaOnly(event) 
  {
    var key = event.keyCode;
      return ((key >= 65 && key <= 90) || key == 8 || key == 9 || key == 20 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40);
  };

  // Function to prevent writing alpha character etc
  function numberOnly(event) 
  {
    var key = event.keyCode;
      return ((key >= 48 && key <= 57) || key == 8 || key == 9 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40);
  };
</script>