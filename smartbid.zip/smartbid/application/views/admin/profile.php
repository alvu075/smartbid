<?php
	include 'includes/header.php';
	foreach ($result as $row) 
  	{
    	$name  = $row->userName;
    	$phone = $row->userPhone;
    	$email = $row->userEmail;
    	$image = $row->userImage;
 	}
?>	
	<div class="col-sm-9 col-sm-offset-3 col-lg-9 col-lg-offset-2 main">
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Admin Profile</h1>
			</div>
		</div><!--/.row-->
		
<div class="panel panel-container">
	<div class="row">
		<section class="content">
    		<div class="row"> 
     			<div class="profile-pic col-md-offset-2 col-md-3 text-center">
        			<?php 
         			echo @$error;
        			?>
       				<img src="<?=base_url();?>assets/images/adminProfile/<?=$image;?>" class="img-responsive" >
        			<h3><?=$name;?></h3>
        			<button class="btn btn-primary" data-toggle="modal" data-target="#dpModal">Change Picture</button><br><br>
     			</div>
      		<div class="personal-details col-md-4 col-md-offset-1">
				<h3 class="box-title text-center">Personal Details</h3>
				<h4><b>Name :</b></h4>
        		<span class="profile-details"><?=$name;?></span><br>
        		<h4><b>Phone Number :</b></h4>
        		<span class="profile-details"><?=$phone;?></span><br>
        		<h4><b>Email :</b></h4>
        		<span class="profile-details"><?=$email;?></span><br><br>
        		<button class="btn btn-primary btnEditProfile" data-toggle="modal" data-target="#profileDetailsModal"><i class="fa fa-edit"></i>&nbsp;&nbsp;Edit Profile</button><br><br>
			</div>
			</div>
		</section>	<!--/.row-->
	</div>
</div>	<!--/.main-->

<!-- Profile Picture Modal -->
<div class="modal fade" id="dpModal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
    	<div class="modal-content col-md-8 col-md-offset-3">
        	<div class="modal-header">
          		<button type="button" class="close" data-dismiss="modal">&times;</button>
          		<h4 class="modal-title">Change Your Profile Picture</h4>
        	</div>
        	<div class="modal-body">
          		<form action="<?=base_url();?>Admin/updatePicture" method="POST" enctype="multipart/form-data">
            		<div class="form-group">
              			<img src="<?=base_url();?>assets/images/adminProfile/<?=$image;?>" class="img-responsive">
            		</div>
            		<div class="form-group">
              			<input type="file" class="form-control" required name="userImage" accept="Image/*" required>
            		</div>
            		<div class="modal-footer form-group">
              			<button type="submit" class="btn btn-primary">Update</button>
              			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            		</div>
          		</form>
        	</div>
     	</div>
    </div>
</div>
<!-- End Profile Picture Modal -->

<!-- Profile Details Modal -->
<div class="modal fade" id="profileDetailsModal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      	<div class="modal-content col-md-8 col-md-offset-3">
        	<div class="modal-header">
          		<button type="button" class="close" data-dismiss="modal">&times;</button>
          		<h4 class="modal-title">Change Your Profile Details</h4>
        	</div>
        	<div class="modal-body">
          		<form role="form" action="<?=base_url();?>Admin/updateProfileDetails" method="post">
            		<div class="box-body">
              			<div class="form-group">
                		<label>User Name</label>
                		<input type="text" class="form-control" value="<?=$name;?>" name="txtName" onkeydown="return alphaOnly(event);">
              		</div>
              		<div class="form-group">
                		<label>User Phone Number</label>
                		<input type="text" class="form-control" minlength="11" maxlength="11" value="<?=$phone;?>" name="txtphoneNumber" onkeydown="return numberOnly(event);">
              		</div>
              		<div class="form-group">
                		<label>User Email</label>
                		<input type="email" class="form-control"  value="<?=$email;?>" name="txtemail">
              		</div>
            </div><!-- /.box-body -->
            		<div class="modal-footer form-group">
              			<button type="submit" class="btn btn-primary">Update</button>
              			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            		</div>
          		</form>
        	</div>
    	</div>
    </div>
</div>
<!-- End Profile Details Modal -->
<?php
	include 'includes/footer.php';
	$this->load->view('alert');
?>
<script>
  // Function to prevent writing number etc
  function alphaOnly(event) 
  {
    var key = event.keyCode;
      return ((key >= 65 && key <= 90) || key == 8 || key == 9 || key == 20 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40);
  };

  // Function to prevent writing alpha character etc
  function numberOnly(event) 
  {
    var key = event.keyCode;
      return ((key >= 48 && key <= 57) || key == 8 || key == 9 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40);
  };
</script>