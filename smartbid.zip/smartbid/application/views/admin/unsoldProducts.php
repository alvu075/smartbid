<?php
	include 'includes/header.php';
  foreach ($unsoldProducts as $row) 
    
?>	
  <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
    <div class="row">
      <ol class="breadcrumb">
        <li><a href="#">
          <em class="fa fa-home"></em>
        </a></li>
        <li class="active">View Unsold Products</li>
      </ol>
    </div><!--/.row-->
    
    <div class="row">
      <div class="col-lg-12">
        <h1 class="page-header">View Unsold Products</h1>
      </div>
    </div><!--/.row-->
      <?php
        if($countMyProducts>0)
        {
      ?>
						<div class="panel panel-container">
      <div class="row">
        <div class="col-md-10 col-md-offset-1">
          <h3 class="box-title text-center">All Unsold Products</h3>
					<table class="table table-striped table-bordered">
						<thead>
							<th>Sr. No.</th>
              				<th>Category Name</th>
              				<th>Product Name</th>
              				<th>Price</th>
              				<th>Description</th>
             				<th>Status</th>
             				<th>Quantity</th>
             				<th>Start Date</th>
             				<th>End Date</th>
               				<th>Image</th>
                      <th>Action</th>
						</thead>
						<tbody>
          					<?php
            					$counter = 0;
            					foreach ($unsoldProducts as $row) 
            					{
             						$srNo= ++$counter;
                        			$prodID = $row->prodID;
             						 $catName = $row->catName;
              						$prodName = $row->prodName;
              						$prodPrice = $row->prodPrice;
              						$description = $row->prodDescription;
              						$status = $row->prodStatus;
              						$prodQuantity = $row->prodQuantity;
              						$startDate = $row->prodStartDate;
              						$endDate = $row->prodEndDate;
              						$image = $row->prodImage;			

                          $currentDate = date('Y-m-d');
                          $days = round(abs(strtotime($endDate) - strtotime($currentDate))/86400);
         			 		?>
              						<tr>
									<td><?=$srNo; ?></td>
                					<td><?=$catName; ?></td>
                					<td><?=$prodName; ?></td>
                					<td><?=$prodPrice; ?></td>
                					<td><?=$description; ?></td>
                					<td><?=$status; ?></td>
                					<td><?=$prodQuantity; ?></td>
                					<td><?=$startDate; ?></td>
                					<td><?=$endDate; ?></td>	
                					<td><img src="<?=base_url();?>/assets/images/ProductsImage/<?=$image; ?>" class="img-responsive" style="width: 40px;height: 40px;"></td>
                          <?php
                            if($days<=1)
                            { ?>
                              <td><i class="fa fa-ban" title="Disabled" style="color:red;"></i>
                              </td>    
                            <?php 
                            }
                            else
                            { ?>
                              <td>
                                <a href="<?=base_url();?>Product/editProduct/<?=$prodID;?>"><i class="fa fa-pencil" title="Edit"></i></a>
                              </td>
                           <?php }
                            ?>
							</tr>
							<?php } ?>
						</tbody>
					</table><br><br>
				</div>
      <?php 
        }
        else
        {  
          echo '<div>
                  <h3 class="text-center">Dear seller you don\'t have any unsold product yet.</h3><br><br><br>
                  </div>';
        }?>
			</div><!--/.row-->
		</div>
	</div>	<!--/.main-->
<?php
	include 'includes/footer.php';
	$this->load->view('alert');
?>