<?php
	include 'includes/header.php';
	foreach ($result as $row) 
  	{
    	$name  = $row->userName;
    	$phone = $row->userPhone;
    	$email = $row->userEmail;
    	$image = $row->userImage;
 	}
?>	
	<div class="col-sm-9 col-sm-offset-3 col-lg-9 col-lg-offset-2 main">
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Change Password</h1>
			</div>
		</div><!--/.row-->
		
<div class="panel panel-container">
	<div class="row">
		<section class="content">
      <div class="row">
      <!-- left column -->
        <div class="col-md-offset-3 col-md-6">
              <!-- general form elements -->
              <div class="box box-primary" >
                  <div class="box-header with-border">
                      <h3 class="box-title">Change Your Password</h3>
                  </div><!-- /.box-header -->
                  <!-- form start -->
                  <form role="form" autocomplete="off" action="<?=base_url();?>admin/updatePassword" method="post">
                      <div class="box-body">
                        <div class="form-group">
                          <label>Current Password</label>
                          <input type="password" class="form-control"  placeholder="Enter current password" name="txtCurrentPass" required>
                        </div>
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" id="confirm_password" class="form-control" placeholder="Enter new password" name="txtNewPass" required minlength="6" onfocusout='check();'>
                            <span id='message'></span>
                        </div>
                        <div class="form-group">
                            <label>Confirm Password</label>
                            <input type="password" class="form-control"  placeholder="Re-enter new password" name="txtConfirmPass"  minlength="5" required >
                        </div>
                    </div><!-- /.box-body -->
                    <div class="box-footer text-center">
                        <input type="submit" class="btn btn-primary btnFormsSubmit" name="btnSubmit">
                      </div><br><br>
                  </form>
                </div>
            </div>
        </div>
    </section><!-- End of form section tag --
</div>
<!-- End Profile Details Modal -->
<?php
	include 'includes/footer.php';
	$this->load->view('alert');
?>

<script>
      var check = function()
        {
          if (document.getElementById('password').value ==
        document.getElementById('confirm_password').value) {
        document.getElementById('message').style.color = 'green';
        document.getElementById('message').innerHTML = 'Password & Confirm Password Matched';
                              } else {
        document.getElementById('message').style.color = 'red';
        document.getElementById('message').innerHTML = 'Password & Confirm Password is not Matching';
                            }
                          }
</script>