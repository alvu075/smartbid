<?php
	include 'includes/header.php';
?>	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Newly Added Products</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Newly Added Products</h1>
			</div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
			<div class="row">
				<div class="col-md-10 col-md-offset-1">
					<h3 class="box-title text-center">All New Products</h3>
          <table class="table table-striped table-bordered">
						<thead>
							<th>Sr. No.</th>
              				<th>Category Name</th>
              				<th>Seller Name</th>
              				<th>Product Name</th>
              				<th>Product Price</th>
              				<th>Product Description</th>
             				<th>Product Status</th>
             				<th>Product Quantity</th>
             				<th>Product Start Date</th>
             				<th>Product End Date</th>
                    <th>Status</th>
               				<th>Product Image</th>
              				<th>Action</th>
						</thead>
						<tbody>
          					<?php
            					$counter = 0;
            					foreach ($newProducts as $row) 
            					{
             						$srNo= ++$counter;
                        $prodID = $row->prodID;
             						$catID = $row->catName;
             						$sellerID = $row->sellerName;
              						$prodName = $row->prodName;
              						$prodPrice = $row->prodPrice;
              						$description = $row->prodDescription;
              						$prodStatus = $row->prodStatus;
              						$prodQuantity = $row->prodQuantity;
              						$startDate = $row->prodStartDate;
              						$endDate = $row->prodEndDate;
              						$image = $row->prodImage;		
                          $status = $row->status;	
         			 		?>
              						<tr>
									<td><?=$srNo; ?></td>
                					<td><?=$catID; ?></td>
                					<td><?=$sellerID; ?></td>
                					<td><?=$prodName; ?></td>
                					<td><?=$prodPrice; ?></td>
                					<td><?=$description; ?></td>
                					<td><?=$prodStatus; ?></td>
                					<td><?=$prodQuantity; ?></td>
                					<td><?=$startDate; ?></td>
                					<td><?=$endDate; ?></td>
                          <td><?=$status; ?></td>	
                					<td><img src="<?=base_url();?>/assets/images/ProductsImage/<?=$image; ?>" class="img-responsive" style="width: 40px;height: 40px;"></td>
                					<td>
									<a href="<?=base_url();?>Product/editNewProduct/<?=$prodID;?>">Activate</a>
								</td>
							</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div><!--/.row-->
		</div>
	</div>	<!--/.main-->
<?php
	include 'includes/footer.php';
	$this->load->view('alert');
?>