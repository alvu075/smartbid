
<?php
	include 'includes/header.php';
	foreach ($categoryDetails as $row) 
	{
		$catID = $row->catID;
		$catName = $row->catName;
	}
?>	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Update Category</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Update Category</h1>
			</div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
			<div class="row">
				<div class="col-md-10 col-md-offset-1">
					<h3 class="box-title text-center">Update Category</h3>
					<?php 
            echo @$error;
          ?>
				<form role="form" method="post" action="<?=base_url();?>Category/updateCategory/<?=$catID;?>">
						<fieldset>
							<div class="form-group">
								<label>Category Name</label>
								<input class="form-control" name="txtcatname" type="name" value="<?=$catName;?>" onkeydown="return alphaOnly(event);" required>
							</div>
							<div class="form-group">
								<label>Status</label>
								<select class="form-control" name="catstatus" required>
									<option value=''>Select Status</option>
									<option value='Active'>Active</option>
									<option value='Inactive'>Inactive</option>
								</select>	
							</div>	
							<div class="text-center">
								<button class="btn btn-primary"> Update Category</button>
							</div>
							<br><br>
						</fieldset>
					</form>
				</div>
			</div><!--/.row-->
		</div>
	</div>	<!--/.main-->
<?php
	include 'includes/footer.php';
	$this->load->view('alert');
?>

<script>
  // Function to prevent writing number etc
  function alphaOnly(event) 
  {
    var key = event.keyCode;
      return ((key >= 65 && key <= 90) || key == 8 || key == 9 || key == 20 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40);
  };
</script>