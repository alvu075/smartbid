	
	<script src="<?=base_url();?>assets/js/jquery-min.js"></script>
	<script src="<?=base_url();?>assets/js/bootstrap3.min.js"></script>
	<script src="<?=base_url();?>assets/js/bootstrap-datepicker.js"></script>
	<script src="<?=base_url();?>assets/js/custom.js"></script>
</body>
</html>