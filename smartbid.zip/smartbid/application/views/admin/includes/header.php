<?php
  if (!$userid=$this->session->has_userdata('userid')) 
  {
    redirect(base_url(). 'admin');
  }
  $userID=$this->session->userdata('userid');
  $CI =& get_instance();
  $CI->load->model('AdminModel');
  $result = $CI->AdminModel->getUserDetails($userID);        
  foreach($result as $row)
  {
    $name= $row->userName;
    $image= $row->userImage;             
  }
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>SMART BID | Dashboard</title>
	<link href="<?=base_url();?>assets/css/bootstrap3.min.css" rel="stylesheet">
	<link href="<?=base_url();?>assets/css/font-awesome.min.css" rel="stylesheet">
	<link href="<?=base_url();?>assets/css/styles.css" rel="stylesheet">
</head>
<body>
	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="#"><span>smartBID</span>Admin</a>
				<ul class="nav navbar-top-links navbar-right">
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#">
							<img src="<?=base_url();?>assets/images/adminProfile/<?=$image;?>" class="img-responsive img-circle" width="30px" height="30px" alt="">
						</a>
						<ul class="dropdown-menu ">
							<li><a href="<?=base_url();?>Admin/profile">Profile</a></li>
							<li class="divider"></li>
							<li><a href="<?=base_url();?>Admin/changePassword">Change Password</a></li>
							<li class="divider"></li>
							<li><a href="<?=base_url();?>Admin/logout">Logout</a></li>
						</ul>
					</li>
				</ul>
			</div>
		</div><!-- /.container-fluid -->
	</nav>
	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			<div class="profile-userpic">
				<img src="<?=base_url();?>assets/images/adminProfile/<?=$image;?>" class="img-responsive" alt="">
			</div>
			<div class="profile-usertitle">
				<div class="profile-usertitle-name"><?=$name;?></div>
				<div class="profile-usertitle-status"><span class="indicator label-success"></span>Online</div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="divider"></div>
		<form role="search">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Search">
			</div>
		</form>
		<ul class="nav menu">
			<li class="active"><a href="<?=base_url();?>Admin/dashboard"><em class="fa fa-dashboard">&nbsp;</em> Dashboard</a></li>
			<li class="parent "><a data-toggle="collapse" href="#users">
				<em class="fa fa-navicon">&nbsp;</em> Manage Users <span data-toggle="collapse" href="#products" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="users">
					<li><a class="" href="<?=base_url();?>Admin/adduser">
						<span class="fa fa-arrow-right">&nbsp;</span> Add User
					</a></li>
					<li><a class="" href="<?=base_url();?>Admin/viewUser">
						<span class="fa fa-arrow-right">&nbsp;</span> View User
					</a></li>
				</ul>
			</li>
			<li class="parent "><a data-toggle="collapse" href="#category">
				<em class="fa fa-navicon">&nbsp;</em> Manage Category <span data-toggle="collapse" href="#users" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="category">
					<li><a class="" href="<?=base_url();?>Category">
						<span class="fa fa-arrow-right">&nbsp;</span> Add Category
					</a></li>
					<li><a class="" href="<?=base_url();?>Category/viewCategory">
						<span class="fa fa-arrow-right">&nbsp;</span> View Category
					</a></li>
				</ul>
			</li>
			<li class="parent "><a data-toggle="collapse" href="#products">
				<em class="fa fa-navicon">&nbsp;</em> Manage Products <span data-toggle="collapse" href="#users" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="products">
					<li><a class="" href="<?=base_url();?>Product">
						<span class="fa fa-arrow-right">&nbsp;</span> Add Product
					</a></li>
					<li><a class="" href="<?=base_url();?>Product/newProducts">
						<span class="fa fa-arrow-right">&nbsp;</span> New Product
					</a></li>
					<li><a class="" href="<?=base_url();?>Product/viewProduct">
						<span class="fa fa-arrow-right">&nbsp;</span> View Product
					</a></li>
					<li><a class="" href="<?=base_url();?>Product/soldProducts">
						<span class="fa fa-arrow-right">&nbsp;</span> Sold  Product
					</a></li>
					<li><a class="" href="<?=base_url();?>Product/unsoldProducts">
						<span class="fa fa-arrow-right">&nbsp;</span> UnSold  Product
					</a></li>

				</ul>
			</li>
			<li><a href="<?=base_url();?>Admin/logout"><em class="fa fa-power-off">&nbsp;</em> Logout</a></li>
		</ul>
	</div><!--/.sidebar-->
</body>
</html>
