<?php
  include 'includes/header.php';
?>
    <!-- About Us Section Start -->
    <section id="aboutUs" class="section">
      <div class="container">
        <div class="section-header">          
          <h2 class="section-title wow fadeIn" data-wow-duration="1000ms" data-wow-delay="0.3s">About Us</h2>
          <hr class="lines wow zoomIn" data-wow-delay="0.3s">
          <p class="section-subtitle wow fadeIn" data-wow-duration="1000ms" data-wow-delay="0.3s">Bidding is an offer to set a price by an individual or business for a product or service or a demand that something be done. <br>SmartBid allow you to purchase a wide array of products online for 24 hours a day and 7 days a week, often at great prices.<br>People bid online for the items they willing to buy.SmartBid is the best venue that you can choose to buy stuff. <br>It’s a very easy process, only you have to register on SmartBid then you will start bidding. </p>
        </div>
      </div>
    </section>
    <!-- About Us Section End -->

    <?php
    if(!$this->session->userdata('sellerID')) 
    {?>
    <!-- categories section Start -->
    <section id="categories" class="section">
      <div class="container">
        <div class="section-header">          
          <h2 class="section-title">All Categories</h2>
          <hr class="lines">
          <p class="section-subtitle"></p>
        </div>
        <div class="row">
          <?php 
            foreach ($categories as $row) 
            {
              $catID = $row->catID;
              $catName = $row->catName;
              $catImage = $row->catImage;
              $catDescription = $row->catDescription;
          ?>
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="single-team">
              <img src="<?=base_url()?>assets/images/CategoryImage/<?=$catImage;?>" alt="" width="50px" height="300px">
              <div class="team-details">
                <div class="team-inner">
                  <h4 class="team-title"><?=$catName;?></h4>
                  <p><?=$catDescription;?></p>
                  <a href="<?=base_url();?>Customer/viewproducts/<?=$catID;?>" class="btn btn-common wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="400ms">View Product</a>
                </div>
              </div>
            </div><br><br>
          </div>
        <?php } ?>
        </div>
      </div>
    </section>
    <!-- Categories section End -->



<section id="products" class="section">
      <div class="container">
        <div class="section-header">          
          <h2 class="section-title">All Products</h2>
          <hr class="lines">
          <p class="section-subtitle"></p>
        </div>
        <div class="row">
          <?php 
            foreach ($products as $row) 
            {
              $prodID = $row->prodID;
              $prodName = $row->prodName;
              $prodImage = $row->prodImage;
              $prodPrice = $row->prodPrice;
              $prodDescription = $row->prodDescription;
          ?>
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="single-team">
              <img src="<?=base_url()?>assets/images/ProductsImage/<?=$prodImage;?>" alt="" width="50px" height="300px">
              <div class="team-details">
                <div class="team-inner">
                  <h4 class="team-title"><?=$prodName;?></h4>
                  <p><?=$prodDescription;?></p>
                  <h4 class="team-title">Rs.<?=$prodPrice;?><h4>
                  <a href="<?=base_url();?>Customer/viewproductsdetail/<?=$prodID;?>" class="btn btn-common wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="400ms">View Detail</a>
                </div>
              </div>
            </div><br><br>
          </div>
        <?php } ?>
        </div>
      </div>
    </section>
      <?php } ?>
    
    <!-- Services Section Start -->
    <section id="services" class="section">
      <div class="container">
        <div class="section-header">          
          <h2 class="section-title wow fadeIn" data-wow-duration="1000ms" data-wow-delay="0.3s">Our Services</h2>
          <hr class="lines wow zoomIn" data-wow-delay="0.3s">
          <p class="section-subtitle wow fadeIn" data-wow-duration="1000ms" data-wow-delay="0.3s"></p>
        </div>
        <div class="row">
          <div class="col-md-4 col-sm-6">
            <div class="item-boxes wow fadeInDown" data-wow-delay="0.2s">
              <div class="icon">
                <i class="lnr lnr-pencil"></i>
              </div>
              <h4>Online Bidding</h4>
              <p></p>
            </div>
          </div>
          <div class="col-md-4 col-sm-6">
            <div class="item-boxes wow fadeInDown" data-wow-delay="0.8s">
              <div class="icon">
                <i class="lnr lnr-code"></i>
              </div>
              <h4>Notification Fastly</h4>
              <p></p>
            </div>
          </div>
          <div class="col-md-4 col-sm-6">
            <div class="item-boxes wow fadeInDown" data-wow-delay="1.2s">
              <div class="icon">
                <i class="fa fa-comments"></i>
              </div>
              <a href="<?=base_url();?>Customer/feedback" style="color: black"><h4>Give Feedback</h4></a>
              <p></p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Services Section End -->


    <!-- testimonial Section Start -->
    <div id="testimonial" class="section" data-stellar-background-ratio="0.1">
      <div class="container">
        <div class="row justify-content-md-center">
          <div class="col-md-12">
            <div class="touch-slider owl-carousel owl-theme">
              <?php 
              foreach ($sellerFeedback as $row) 
              {
                $name = $row->name;
                $feedback = $row->feedback;
                $date = $row->date;
                $time = $row->time;
                $sellerPhoto = $row->sellerPhoto;
                ?>
              <div class="testimonial-item">
                <img src="<?=base_url()?>assets/images/customers/<?=$sellerPhoto;?>" alt="Client Testimonoal" />
                <div class="testimonial-text">
                  <p></p>
                  <h3><?=$name;?></h3>
                  <span><?=$feedback;?></span>
                </div>
              </div>
            <?php } ?>

            <?php 
              foreach ($bidderFeedback as $row) 
              {
                $name = $row->name;
                $feedback = $row->feedback;
                $date = $row->date;
                $time = $row->time;
                $bidderPhoto = $row->bidderPhoto;
                ?>
              <div class="testimonial-item">
                  <img src="<?=base_url()?>assets/images/customers/<?=$bidderPhoto;?>" alt="Client Testimonoal" />
                <div class="testimonial-text">
                  <p></p>
                  <h3><?=$name;?></h3>
                  <span><?=$feedback;?></span>
                </div>
              </div>
            <?php } ?>
            </div>
          </div>
        </div>        
      </div>
    </div>
    <!-- testimonial Section Start -->

    <!-- Contact Section Start -->
    <section id="contact" class="section">      
      <div class="contact-form">
        <div class="container">
          <div class="row">     
            <div class="col-lg-6 col-sm-6 col-xs-12">
              <div class="contact-us">
                <h3>Contact With us</h3>
                <div class="contact-address">
                  <p>KFUEIT Rahim Yar Khan</p>
                  <p class="phone">Phone: <span>(+92 303 2521026)</span></p>
                  <p class="email">E-mail: <span>(contact@smartbid.com)</span></p>
                </div>
                <div class="social-icons">
                  <ul>
                    <li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li class="google-plus"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                    <li class="linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    <li class="dribbble"><a href="#"><i class="fa fa-dribbble"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>     
            <div class="col-lg-6 col-sm-6 col-xs-12">
              <div class="contact-block">
                <form method="post" action="<?=base_url();?>Customer/contactUs">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <input type="text" class="form-control" name="name" placeholder="Your Name" required>
                      </div>                                 
                    </div>
                    <div class="col-md-12">
                      <div class="form-group">
                        <input type="text" placeholder="Subject" class="form-control" name="subject" required>
                      </div> 
                    </div>
                    <div class="col-md-12">
                      <div class="form-group">
                        <input type="text" placeholder="Your Email" class="form-control" name="email" required>
                      </div> 
                    </div>
                    <div class="col-md-12">
                      <div class="form-group"> 
                        <textarea class="form-control" placeholder="Your Message" rows="8" name="message" required></textarea>
                      </div>
                      <div class="submit-button text-center">
                        <button class="btn btn-common" type="submit">Send Message</button>
                        <div class="clearfix"></div> 
                      </div>
                    </div>
                  </div>            
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>           
    </section>
    <!-- Contact Section End -->
<?php
  include 'includes/footer.php';
  $this->load->view('alert');
?>