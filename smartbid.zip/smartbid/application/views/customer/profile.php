<?php
	include 'includes/header.php';
  if($this->session->userdata('sellerID'))
  {
    foreach($sellerDetails as $row)
    { 
      $customerName = $row->sellerName;
      $customerImage = $row->sellerPhoto;
      $customerPhone = $row->sellerPhone; 
      $customerEmail = $row->sellerEmail;
      $customerGender = $row->sellerGender;
      $customerCity = $row->sellerCity;
      $customerAddress = $row->sellerAddress;
      $customerPassword = $row->sellerPassword;
    }
  }
  if($this->session->userdata('bidderID'))
  {
    foreach($bidderDetails as $row)
    { 
      $customerName = $row->bidderName;
      $customerImage = $row->bidderPhoto;
      $customerPhone = $row->bidderPhone; 
      $customerEmail = $row->bidderEmail;
      $customerGender = $row->bidderGender;
      $customerCity = $row->bidderCity;
      $customerAddress = $row->bidderAddress;
      $customerPassword = $row->bidderPassword;
    }
  }
?>
<title>Profile</title>
<div class="container">
  <div class="row my-5">
    <div class="col-md-8 order-lg-2">
      <ul class="nav nav-tabs">
        <li class="nav-item">
          <a href="" data-target="#profile" data-toggle="tab" class="nav-link active">Profile</a>
        </li>
        <li class="nav-item">
          <a href="" data-target="#changePassword" data-toggle="tab" class="nav-link">Change Password</a>
        </li>
      </ul>
      <div class="tab-content py-3">
        <div class="tab-pane active" id="profile">
          <h5 class="mb-3" style="margin-left: 2%;">User Profile</h5>
          <div class="row">
            <div class="col-md-8 table-responsive" style="margin-left: 14%;"> 
              <table class="table table-hover">
                <tbody>
                  <tr>
                    <td><b>Name:</b></td>
                    <td><?=$customerName;?></td>
                  </tr>
                  <tr>
                    <td><b>Phone Number:</b></td>
                    <td><?=$customerPhone;?></td>
                  </tr>
                  <tr>
                    <td><b>Email:</b></td>
                    <td><?=$customerEmail;?></td>
                  </tr>
                  <tr>
                    <td><b>Gender:</b></td>
                    <td><?=$customerGender?></td>
                  </tr>
                  <tr>
                    <td><b>City:</b></td>
                    <td><?=$customerCity?></td>
                  </tr>
                  <tr>
                    <td><b>Address:</b></td>
                    <td><?=$customerAddress?></td>
                  </tr>
                </tbody>
              </table>
            </div>            
          </div><!--/row-->   
          <div class="col-md-10 text-center">
            <button class="btn btn-common" data-toggle="modal" data-target="#profileDetailsModal"><i class="fa fa-edit"></i>&nbsp;&nbsp;Edit Profile</button>
          </div>
        </div>
        <div class="tab-pane" id="changePassword">
          <h5 class="mb-3" style="margin-left: 2%;">Change Password</h5>
          <div class="row">
            <div class="col-md-8 ">           
              <form role="form" action="<?=base_url();?>customer/updatePassword" method="post" autocomplete="off" style="margin-left: 18%;">
                <div class="form-group">
                  <label>Old Password</label>
                  <input type="password" class="form-control" placeholder="Enter old password" name="txtoldpassword" required >
                </div>
                <div class="form-group">
                  <label>New Password</label>
                  <input type="password" class="form-control" minlength="6" placeholder="Enter new password" name="txtnewpassword" required >
                </div>
                <div class="form-group">
                  <label>Re-Enter New Password</label>
                  <input type="password" id="confirm_password" class="form-control" minlength="6" placeholder="Re-Enter new password" name="txtconfirmpassword" required onfocusout='check();'>
                  <span id='message'></span>
                </div>
                <input type="hidden" name="oldpass" value="<?=$customerPassword?>">
                <div class="form-group text-center">
                  <button class="btn btn-common">Change Password</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="col-md-3" style="margin-left: 8%;">
      <img src="<?=base_url();?>assets/images/customers/<?=$customerImage;?>" class="img-fluid"><br><br>
      <div class="text-center">
        <h4><?=$customerName;?></h4>
        <button class="btn btn-common" data-toggle="modal" data-target="#dpModal">Change Profile</button>
      </div>
    </div>
  </div>
</div><br><br><br>

<!-- Profile Picture Modal -->
  <div class="modal fade" id="dpModal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content col-md-10">
        <div class="modal-header">
          <h4 class="modal-title">Update Your Profile Picture</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body col-md-12">
          <form action="<?=base_url();?>Customer/updatePicture" method="post" enctype="multipart/form-data">
            <div class="form-group">
              <img src="<?=base_url();?>assets/images/customers/<?=$customerImage;?>" class="img-fluid">
            </div>
            <div class="form-group">
              <input type="file" class="form-control" required name="customerImage" accept="Image/*">
            </div>
            <div class="modal-footer form-group">
              <button type="submit" class="btn btn-common">Update</button>
              <button type="button" class="btn btn-common" data-dismiss="modal">Close</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<!-- End Profile Picture Modal -->

<!-- Profile Details Modal -->
<div class="container">
  <div class="modal fade" id="profileDetailsModal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Update Your Profile Details</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <form role="form" action="<?=base_url();?>Customer/updateProfile" method="post" autocomplete="off">
            <div class="box-body">
              <div class="form-group">
                <label>Name</label>
                <input type="text" class="form-control" value="<?=$customerName;?>" onkeydown="return alphaOnly(event);" name="txtname" required>
              </div>
              <div class="form-group">
                <label>Phone Number</label>
                <input type="text" class="form-control" minlength="11" maxlength="11" value="<?=$customerPhone;?>" name="txtphoneNumber" onkeydown="return numberOnly(event);" required>
              </div>
              <div class="form-group">
                <label>Email</label>
                <input type="email" class="form-control"  value="<?=$customerEmail;?>" name="txtemail" required>
              </div>
              <div class="form-group">
                <label>Gender</label>
                <select class="form-control" name="ddgender" required>
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
              </div>
              <div class="form-group">
                <label>City</label>
                <input type="text" class="form-control" value="<?=$customerCity;?>" name="txtcity" onkeydown="return alphaOnly(event);" required>
              </div>
              <div class="form-group">
                <label>Address</label>
                <input type="text" class="form-control" value="<?=$customerAddress;?>" name="txtaddress" required>
              </div>
            </div><!-- /.box-body -->
            <div class="modal-footer form-group">
              <button type="submit" class="btn btn-common">Update</button>
              <button type="button" class="btn btn-common" data-dismiss="modal">Close</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div></div>
<!-- End Profile Details Modal -->

<?php
	include 'includes/footer.php';
  $this->load->view('alert');
?>
<script>
  // Function to prevent writing number etc
  function alphaOnly(event) 
  {
    var key = event.keyCode;
      return ((key >= 65 && key <= 90) || key == 8 || key == 9 || key == 20 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40);
  };

  // Function to prevent writing alpha character etc
  function numberOnly(event) 
  {
    var key = event.keyCode;
      return ((key >= 48 && key <= 57) || key == 8 || key == 9 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40);
  };

  var check = function()
    {
      if (document.getElementById('password').value ==
    document.getElementById('confirm_password').value) {
    document.getElementById('message').style.color = 'green';
    document.getElementById('message').innerHTML = 'matching';
    } else {
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'not matching';
      }
    }
</script>