<title>Foget Password</title>
<?php
	include 'includes/header.php';
?>

	<div class="container-fluid">
		<div class="container"><br><br>
			<form method="post" action="<?=base_url();?>customer/bidderResetPassword" autocomplete="off" style="margin-left: 25%;">
				<h4 class="text-center col-md-8">Forget Password? Don't Worry</h4>
				<div class="text-center col-md-8">
					<small class="text-center">We will send you a link to reset your password.</small>
				</div><br><br>
				<div class="form-group col-md-8">
					<input class="form-control" type="text" name="txtemail" placeholder="Enter Your Registered Email" required>
				</div><br>
				<div class="form-group text-center col-md-8">
					<button type="submit" name="btnLogin" class="btn btn-common">Reset Password</button><br><br>
					
				</div>
				<div>
					<span class="pull-left">New User ? <a href="<?=base_url();?>customer/bidderSignUp">Signup</a></span>
					<span class="pull-right">Already registered ? <a href="<?=base_url();?>customer/bidderLogin">Sign in</a></span>
				</div>
			</form>			
		</div>
	</div>
<br><br><br><br><br>
<?php
	include 'includes/footer.php';
	$this->load->view('alert');
?>
