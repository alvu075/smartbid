
<?php
  include 'includes/header.php';
?>
<title>Products</title>
    <section id="products" class="section">
      <div class="container">
        <div class="section-header">          
          <h2 class="section-title">All Products</h2>
          <hr class="lines">
        </div>
        <div class="row">
          <?php 
            foreach ($products as $row) 
            {
              $prodID = $row->prodID;
              $prodName = $row->prodName;
              $prodImage = $row->prodImage;
              $prodPrice = $row->prodPrice;
              $prodDescription = $row->prodDescription;
          ?>
          <div class="col-lg-4 col-md-6 col-xs-12">
            <div class="single-team">
              <img src="<?=base_url()?>assets/images/ProductsImage/<?=$prodImage;?>" alt="" width="50px" height="300px">
              <div class="team-details">
                <div class="team-inner">
                  <h4 class="team-title"><?=$prodName;?></h4>
                  <p><?=$prodDescription;?></p>
                  <h4 class="team-title">Rs.<?=$prodPrice;?><h4>
                  <a href="<?=base_url();?>Customer/viewproductsdetail/<?=$prodID;?>" class="btn btn-common wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="400ms">View Detail</a>
                </div>
              </div>
            </div><br><br>
          </div>
        <?php } ?>
        </div>
      </div>
    </section>

<?php
  include 'includes/footer.php';
  $this->load->view('alert');
?>
