
<?php
	include 'includes/header.php';
	foreach ($productDetails as $row) 
	{
		$prodID = $row->prodID;
    	$prodName = $row->prodName;
      $prodPrice = $row->prodPrice;
      $prodQuantity = $row->prodQuantity;
      $prodStartDate = $row->prodStartDate;
      $prodEndDate = $row->prodEndDate;
    	$description = $row->prodDescription;
	}
?>	
	<div class="container-fluid">
    <div class="container"><br><br><br>
           <form method="post" action="<?=base_url();?>Customer/updateProduct/<?=$prodID;?>" autocomplete="off" class="col-md-6"   style="margin-left: 25%;" enctype="multipart/form-data">
            <h3 class="text-center">Update Product</h3><br>
						<fieldset>
                        <div class="form-group">
                            <label>Product Name</label>
                                <input type="text" class="form-control" value="<?=$prodName;?>" name="txtprodName" required>
                          </div>
              				    <div class="form-group">
                                <label>Select Category</label>
               				    <select class="form-control" name="ddCategory" required>
                  				<option value="">Select Category</option>
                  				<?php
                    			foreach ($categories as $row)
                    			{
                     			$id = $row->catID;
                      			$name = $row->catName;
                  				?>
                  				<option value="<?=$id;?>"><?=$name;?></option>
                 				 <?php } ?>
                				  </select>
              				    </div>
                          <div class="form-group">
                            <label>Product Price</label>
                                <input class="form-control noZero" id="price" value="<?=$prodPrice;?>" name="txtprodprice" type="text" onkeydown="return numberOnly(event);" required>
                          </div>
                          <div class="form-group">
                            <label>Product Quantity</label>
                                <input class="form-control noZero" value="<?=$prodQuantity;?>" name="txtprodquantity" id="quantity" type="name" onkeydown="return numberOnly(event);"required>
                          </div>
                          <div class="form-group">
                            <label>Product Start Date</label>
                                <input class="form-control" value="<?=$prodStartDate;?>" name="txtstartdate" type="Date" id="startDate" required min="<?php echo date('Y-m-d');?>">
                          </div>
                          <div class="form-group">
                              <label>Product End Date</label>
                                <input class="form-control" value="<?=$prodEndDate;?>"  name="txtenddate" type="Date" required id="endDate" min="<?php echo date('Y-m-d');?>">
                            </div>
                            <div class="form-group">
                                <label>Product Description</label>
                                <input type="text" class="form-control" value="<?=$description;?>" name="txtprodDescription" required>
                            </div>
                            <div class="form-group">
                                <label>Product Image</label>
                                <input type="file" class="form-control" name="prodImage" accept="Image/*">
                            </div>
                            <div class="text-center">
								<button  type="submit" name="btnLogin" class="btn btn-login"> Update Product</button>
							</div>
							<br><br>
						</fieldset>
					</form>
				</div>
			</div><!--/.row-->
		</div>
	</div>	<!--/.main-->
<?php
	include 'includes/footer.php';
	$this->load->view('alert');
?>

<script>
  // Function to prevent writing number etc
  function alphaOnly(event) 
  {
    var key = event.keyCode;
      return ((key >= 65 && key <= 90) || key == 8 || key == 9 || key == 20 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40);
  };

  function numberOnly(event) 
  {
    var key = event.keyCode;
      return ((key >= 48 && key <= 57) || key == 8 || key == 9 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40);
  };

$(document).ready(function(){
    $('.noZero').focusout(function()
    {
        var price = parseInt($('#price').val());
        if(price<1)
        {
           alert("Please Enter Price More Than 0");
           $('#price').val('');
            document.getElementById("price").focus();
        }

        var quantity = parseInt($('#quantity').val());
        if(quantity<1)
        {
           alert("Please Enter Quantity 1 OR more Than 1");
           $('#quantity').val('');
            document.getElementById("quantity").focus();
        }
  });

    $('#startDate').focusout(function()
    {
    var startDate = $('#startDate').val();
    var currentDate = new Date().toISOString().slice(0, 10);
        if(startDate<currentDate)
        {
           alert("Previous date selection is not allowed");
           $('#startDate').val('');
        }
    });

    $('#endDate').focusout(function()
    {
    var endDate = $('#endDate').val();
    var currentDate = new Date().toISOString().slice(0, 10);
        if(endDate<currentDate)
        {
           alert("Previous date selection is not allowed");
           $('#endDate').val('');
        }
    });   
});    
</script>