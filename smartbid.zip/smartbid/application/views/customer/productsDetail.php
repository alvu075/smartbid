<?php
  include 'includes/header.php';
?>
<style type="text/css">
  .hide{
  display:none;
}
.show{
  display:block;
}
</style>
<title>Products</title>
    <section id="products" class="section">
      <div class="container">
        <div class="section-header">          
          <h2 class="section-title">Product Detail</h2>
          <hr class="lines">
        </div>
        <div class="row">
          <?php 
            foreach ($productsdetails as $row) 
            {
              $prodID = $row->prodID;
              $prodName = $row->prodName;
              $prodImage = $row->prodImage;
              $prodPrice = $row->prodPrice;
              $prodStartDate=$row->prodStartDate;
              $prodEndDate=$row->prodEndDate;
              $prodDescription = $row->prodDescription;
          ?>
          <div class="col-md-4" style="margin:0% 13%;">
            <div class="single-team">
              <img src="<?=base_url()?>assets/images/ProductsImage/<?=$prodImage;?>" alt="" width="50px" height="300px">
            </div>
          </div>
          <div class="col-md-4">
            <div class="team-details"  >
              <div class="team-inner ">
                <h3 ><?=$prodName;?></h4>
                <p>Product Description:&nbsp;&nbsp;<?=$prodDescription;?></p>
                <p>Start Date:&nbsp;&nbsp;<?=$prodStartDate;?></p>
                <p>End Date:&nbsp;&nbsp;<?=$prodEndDate;?></p>
                <h4 class="team-title">Original Price Rs.<?=$prodPrice;?><h4>
                <button class="btn btn-common wow fadeInUp bidNow" data-wow-duration="1000ms" data-wow-delay="400ms" onclick="checkLogin();">Bid Now</button>
                
                <div class="hide text-center" id="bidNowTextBox" style="margin-top: 3%;">
                <?php
                if($this->session->userdata('bidderID')) 
                {?>
                  <form method="post" name="bid" action="<?=base_url();?>Bid/newBid" onsubmit="return myFunction()">
                    <div class="form-group">
                      <input type="text" class="form-control" name="bidAmount"  placeholder="Enter your bid amount" onkeydown="return numberOnly(event);" id="bidAmount">
                      <input type="hidden" name="productID" value="<?=$prodID;?>">
                      <p id="errorid" style="color: red"></p>
                    </div>
                    <div class="form-group">
                      <button class="btn btn-common">Submit</button>
                    </div>
                  </form>
              <?php 
              } 
              else
              {
                echo '<p style="color: red">You are not logged in. Please login to bid on products</p>';
              } ?>
              </div>
              </div>
             </div>
          </div>
        </div><br><br><br><br>
        <?php } ?>

        <?php
          $ID = 0;
          foreach ($bidsdetail as $row) 
          {
            $ID = $row->bidID;
          }
          if($ID>0)
          { 
        ?>
        <div class="row">
          <div class="table">
            <h2 class="text-center">Total Bids Details</h2><br><br>
            <table class="table table-striped table-bordered">
              <thead>
                <th>Sr. No.</th>
                <th>Bidder Name</th>
                <th>Last Bid Amount</th>
                <th>Date</th>
                <th>Time</th>
              </thead>
              <tbody>
                <?php
                  $counter = 0; 
                  foreach ($bidsdetail as $row) 
                  { 
                    $srNo = $counter+1;
                    $bidderName = $row->bidderName;
                    $bidAmount = $row->bidAmount;
                    $bidDate = $row->date;
                    $bidTime = $row->time;
                ?>

                  <tr>
                    <td><?=$srNo;?></td>
                    <td><?=$bidderName;?></td>
                    <td><?=$bidAmount;?></td>
                    <td><?=$bidDate;?></td>
                    <td><?=$bidTime;?></td>
                  </tr>

                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
        <?php }
          else
          {
            echo "<div>
                  <h3 class='text-center'>No bid on this product yet.</h3>
                  </div>";
          }?>
        </div>
      </div>
    </section>

<?php
  include 'includes/footer.php';
  $this->load->view('alert');

  if(!isset($bidAmount))
    $bidAmount = 0;
?>
<script>
  function myFunction() 
  {
    var id = "<?=$ID;?>";
      
    if(id==0)  
    {
      
      var prodPrice = parseInt("<?=$prodPrice;?>");
      var bidAmount = parseInt(document.forms["bid"]["bidAmount"].value);
      console.log(prodPrice);
      if(bidAmount<=prodPrice)
      {
        document.getElementById("errorid").innerHTML = "Bid amount can\'t be less than the starting price";
        $('#bidAmount').val('');
        document.getElementById("bidAmount").focus();
        return false;
      }
    }
    else 
    {
      var lastBid = parseInt("<?=$bidAmount;?>");
      var bidAmount = parseInt(document.forms["bid"]["bidAmount"].value);
      if(bidAmount<=lastBid)
      {
        document.getElementById("errorid").innerHTML = "Bid amount can\'t be less than the last bid amount";
        $('#bidAmount').val('');
        document.getElementById("bidAmount").focus();
        return false;
      }
    }

    var a = document.forms["bid"]["bidAmount"].value;
    if (a == "") 
    {
      document.getElementById("errorid").innerHTML = "Please enter bid amount";
      $('#bidAmount').val('');
      document.getElementById("bidAmount").focus();
      return false;
    }
    return true;
  }

</script>
<script>
  function numberOnly(event) 
  {
    var key = event.keyCode;
      return ((key >= 48 && key <= 57) || key == 8 || key == 9 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40);
  };
  
  $(document).ready(function() {
    $(".bidNow").click(function(){
      $('#bidNowTextBox').toggle();
    });
  });
</script>