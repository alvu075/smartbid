<?php 
	include 'includes/header.php';
?>

<title>Seller Login</title>

	<div class="container-fluid">
		<div class="container"><br><br><br>
			<form method="post" action="<?=base_url();?>Customer/verifysellerLogin" autocomplete="off" style="margin-left: 25%;">

				<div class="col-md-8">
				<h4 class="text-center text-danger"><?php echo $this->session->flashdata('notLogin'); ?></h4>
				<h3 class="text-center">Seller Login</h3><br><br>
				<p class="text-center" style="font-size: 30px;">Login to your account</p><br></div>
				<div class="col-md-8">
				<div class="form-group">
					<input class="form-control" type="text" name="txtphone" placeholder="Enter Your Email" required data-error="Please enter your email">
					<div class="help-block with-errors"></div>
				</div>
			</div>

				<div class="col-md-8">
				<div class="form-group">
					<input class="form-control" type="password" id="password" name="txtpassword" placeholder="Password" required>
					<div class="help-block with-errors"></div>
				</div>
			</div>

				<div class="col-md-8">
				<div class="form-group text-center">
					<button type="submit" name="btnLogin" class="btn btn-login">Login</button><br><br>
					</div>
				</div>

				<div class="col-md-8">
					<span class="pull-left">New User ? <a href="<?=base_url();?>customer/sellerSignUp">Signup</a></span>
					<a href="<?=base_url();?>Customer/sellerForgetPassword" class="pull-right">Forget Password ?</a>
				</div>
			</form>			
		</div>
	</div>
<br><br><br>
<?php
	include 'includes/footer.php';
	$this->load->view('alert');
?>
