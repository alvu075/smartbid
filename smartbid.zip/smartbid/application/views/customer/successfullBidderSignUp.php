<?php
	include 'includes/header.php';
?>
	<title>Successfull Registration</title>

	<div class="container-fluid">
		<div class="container"><br><br><br>
			<div class="text-center">
				<p><h2>Congratulations..!</h2> Your account has been created please check your email for account verfication.</p>	
			</div>		
		</div>
	</div>
<br><br><br>
<?php
	include 'includes/footer.php';
?>
