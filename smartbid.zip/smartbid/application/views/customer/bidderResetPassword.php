<?php
	include 'includes/header.php';
	$email = $this->input->post('email');
	$code = $this->input->post('code');
?>
	<title>Reset Password</title>

	<div class="container-fluid">
		<div class="container"><br><br><br>
			<form method="post" action="<?=base_url();?>customer/bidderPasswordReset" autocomplete="off" style="margin-left: 25%;" >
				<h2 class="text-center col-md-8">Reset your acount password</h2>
				<div class="form-group col-md-8">
					<input class="form-control" type="password" name="txtNewPassword" placeholder="Enter New Password" minlength="6" required>
				</div><br>
				<div class="form-group col-md-8">
					<input class="form-control" type="password" id="confirm_password" name="txtConfirmPassword" placeholder="Re-Enter New Password" minlength="6" required onfocusout='check();'>
					<span id='message'></span>
				</div><br>
				<input type="hidden" name="txtemail" value="<?=$email; ?>">
				<input type="hidden" name="txtcode" value="<?=$code; ?>"hidden>
				<div class="form-group text-center col-md-8">
					<button type="submit" name="btnPassword" class="btn btn-common">Update Password</button><br><br>
				</div>
			</form>			
		</div>
	</div>
<br><br><br>
<?php
	include 'includes/footer.php';
	$this->load->view('alert');
?>
<script>
	var check = function()
  	{
	  	if (document.getElementById('password').value ==
		document.getElementById('confirm_password').value) {
		document.getElementById('message').style.color = 'green';
		document.getElementById('message').innerHTML = 'matching';
		} else {
		document.getElementById('message').style.color = 'red';
		document.getElementById('message').innerHTML = 'not matching';
	    }
  	}
 </script>