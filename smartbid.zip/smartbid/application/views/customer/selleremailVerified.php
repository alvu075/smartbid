<?php
	include 'includes/header.php';
?>
	<title>Email Verified</title>


	<div class="container-fluid">
		<div class="container"><br><br><br>
			<div class="text-center">
				<p><h2>Congratulations..!</h2> Your account has been verified. You can now login to your account</p>	
			</div>		
		</div>
	</div>
<br><br><br>
<?php
	include 'includes/footer.php';
?>