<?php
	include 'includes/header.php';
?>	
<title>Add Product</title>
	<div class="container-fluid">
		<div class="container"><br><br><br>
				   <form method="post" action="<?=base_url();?>Customer/addNewProduct"    	autocomplete=  "off" style="margin-left: 25%;" enctype="multipart/form-data"    >
						<h4 class="text-center text-danger"><?php echo $this->session->flashdata('notLogin'); ?></h4>
						<h3 class="text-center col-md-8">Add New Product</h3><br>
						<fieldset>
							<div class="form-group col-md-8">
								<label>Product Name</label>
								<input class="form-control" placeholder="Enter Product Name" name="txtprodname" type="name" required onkeydown="return numberOnlyAlphaOnly(event);">
							</div>
							<div class="form-group col-md-8">
                					<label>Select Category</label>
                					<select class="form-control" name="ddCategory" required>
                  					<option value="">Select Category</option>
                 					<?php
                   					foreach ($categories as $row)
                    				{
                     				$id = $row->catID;
                      				$name = $row->catName;
                  					?>
                  					<option value="<?=$id;?>"><?=$name;?></option>
                 					<?php } ?>
               						</select>
             				</div>
             				<div class="form-group col-md-8">
								<label>Product Price</label>
								<input class="form-control noZero" id="price" placeholder="Enter Product Price" name="txtprodprice" type="text" onkeydown="return numberOnly(event);" required>
							</div>
							<div class="form-group col-md-8">
								<label>Product Quantity</label>
								<input class="form-control noZero" placeholder="Enter Product Quantity" name="txtprodquantity" id="quantity" type="name" onkeydown="return numberOnly(event);" required>
							</div>
							<div class="form-group col-md-8">
								<label>Product Start Date</label>
								<input class="form-control" placeholder="Enter Name" name="txtstartdate" type="Date" required min="<?php echo date('Y-m-d');?>">
							</div>
							<div class="form-group col-md-8 ">
								<label>Product End Date</label>
								<input class="form-control" placeholder="Enter Name" name="txtenddate" type="Date" id="endDate" min="<?php echo date('Y-m-d');?>" required>
							</div>
							<div class="form-group col-md-8">
									<label>Product Description</label>
									<textarea class="form-control" rows="3" name="proddes"></textarea>
							</div>
							<div class="form-group col-md-8">
									<label>Product Image</label>
								    <input type="file" class="form-control" name='prodimage' required accept="Image/*">
							</div>
							<div class="text-center col-md-8">
								<button  type="submit" name="btnLogin" class="btn btn-login"> Add Product</button>
							</div>
							<br><br>
						</fieldset>
					</form>
				</div>
			</div><!--/.row-->
		</div>
	</div>	<!--/.main-->
<?php
	include 'includes/footer.php';
	$this->load->view('alert');
?>
<script>
  // Function to prevent writing number etc
  function alphaOnly(event) 
  {
    var key = event.keyCode;
      return ((key >= 65 && key <= 90) || key == 8 || key == 9 || key == 20 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40);
  };

  // Function to prevent writing alpha character etc
  function numberOnly(event) 
  {
    var key = event.keyCode;
      return ((key >= 48 && key <= 57) || key == 8 || key == 9 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40);
  };

  function numberOnlyAlphaOnly(event) 
  {
    var key = event.keyCode;
      return ((key >= 48 && key <= 57) || (key >= 65 && key <= 90) || key == 8 || key == 9 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40);
  };

$(document).ready(function(){
    $('.noZero').focusout(function()
    {
        var price = parseInt($('#price').val());
        if(price<1)
        {
           alert("Please Enter Price More Than 0");
           $('#price').val('');
            document.getElementById("price").focus();
        }

        var quantity = parseInt($('#quantity').val());
        if(quantity<1)
        {
           alert("Please Enter Quantity 1 OR more Than 1");
           $('#quantity').val('');
            document.getElementById("quantity").focus();
        }
 	});

    $('#startDate').focusout(function()
    {
 		var startDate = $('#startDate').val();
 		var currentDate = new Date().toISOString().slice(0, 10);
        if(startDate<currentDate)
        {
           alert("Previous date selection is not allowed");
           $('#startDate').val('');
        }
    });

    $('#endDate').focusout(function()
    {
    var endDate = $('#endDate').val();
    var currentDate = new Date().toISOString().slice(0, 10);
        if(endDate<currentDate)
        {
           alert("Previous date selection is not allowed");
           $('#endDate').val('');
        }
    });
});    
</script>