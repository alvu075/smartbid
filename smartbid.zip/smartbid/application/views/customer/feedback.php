<title>Feedback</title>
<?php 
	include 'includes/header.php';
?>	
	<div class="container-fluid">
		<div class="container"><br><br><br>
			<form method="post" action="<?=base_url();?>Customer/postFeedback" style="margin-left: 25%;">
				<h3 class="text-center col-md-8">Feedback</h3><br>
				<p class="text-center col-md-8">Your feedback is very important for us. You can send us feedback for the performance of the SMART RATE UPDATE SYSTEM. Please provide your feedback below.</p><br>
                  <div class="row">
                    <div class="col-md-8">
                      <div class="form-group">
                        <input type="text" class="form-control" name="name" placeholder="Your Name" required>
                      </div>                                 
                    </div>
                    <div class="col-md-8">
                      <div class="form-group">
                        <input type="text" placeholder="Your Email" class="form-control" name="email" required>
                      </div> 
                    </div>
                    <div class="col-md-8">
                      <div class="form-group"> 
                        <textarea class="form-control" placeholder="Your Feedback" rows="8" name="feedback" required></textarea>
                      </div>
                      <div class="submit-button text-center">
                        <button class="btn btn-common" type="submit">Send Feedback</button>
                      </div>
            	    </div>
                </div>            
            </form>			
		</div>
	</div>
<br><br><br>
<?php
	include 'includes/footer.php';
	$this->load->view('alert');
?>