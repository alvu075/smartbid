<?php 
	include 'includes/header.php';
?>

<title>Sign Up</title>

	<div class="container-fluid">
		<div class="container"><br><br><br>
			<form method="post" action="<?=base_url();?>Customer/addBidder" autocomplete="off" style="margin-left: 25%;" enctype="multipart/form-data">
				<div class="col-md-8">
					<h4 class="text-center text-danger"><?php echo $this->session->flashdata('notLogin'); ?></h4>
					<h3 class="text-center">Bidder Sign Up</h3><br>
					<p class="text-center" style="font-size: 30px;">Create a new account</p>
				</div>
				<div class="col-md-8">
					<div class="form-group">
						<label>Name</label>
						<input class="form-control" type="name" name="txtname" placeholder="Enter Name" onkeydown="return alphaOnly(event);" required>
					</div>
				</div>
				<div class="form-group col-md-8">
					<label>Email</label>
					<input class="form-control" type="email" name="txtemail" placeholder="Enter Email" required>
				</div>
				<div class="form-group col-md-8">
					<label>Password</label>
					<input class="form-control" type="password" name="txtpassword" id="password" placeholder="Enter Password" minlength="6"  required>
				</div>
				<div class="form-group col-md-8">
					<label>Confirm Password</label>
					<input class="form-control" type="password" id="confirm_password" name="txtconfirmpassword" placeholder="Enter Confirm Password" "minlength="6" required onfocusout='check();'>
					 <span id='message'></span>
				</div>
				<div class="form-group col-md-8">
					<label>Phone Number</label>
					<input class="form-control" type="text" name="txtphone" placeholder="Enter Phone Number" minlength="11" maxlength="11" onkeydown="return numberOnly(event);" required>
					<div class="invalid-feedback">
		              	Please enter valid email or cell number...!
		            </div>
				</div>
				<div class="form-group col-md-8">
					<label>Gender</label><br>
					<input type="radio" name="gender" value="male" checked required=""> Male 
  					&nbsp;&nbsp;&nbsp;<input type="radio" name="gender" value="female" required=""> Female<br>
				</div>
				<div class="form-group col-md-8">
					<label>City</label>
					<input class="form-control" type="name" name="txtcity" placeholder="Enter City" required>
				</div>
				<div class="form-group col-md-8">
					<label>Address</label>
					<input class="form-control" type="name" name="txtaddress" placeholder="Enter Address" required>
				</div>
				<div class="form-group col-md-8">
					<label>Image</label>
					<input type="file" class="form-control" name='bidderImage' required accept="Image/*">
				</div>
				<div class="form-group text-center col-md-8">
					<button type="submit" name="btnLogin" class="btn btn-login">Sign Up</button><br><br>	
				</div>
			</form>			
		</div>
	</div>
<br><br><br>
<?php
	include 'includes/footer.php';
	$this->load->view('alert');
?>
<script>
  // Function to prevent writing number etc
  function alphaOnly(event) 
  {
    var key = event.keyCode;
      return ((key >= 65 && key <= 90) || key == 8 || key == 9 || key == 20 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40);
  };

   function numberOnly(event) 
  {
    var key = event.keyCode;
      return ((key >= 48 && key <= 57) || key == 8 || key == 9 || key == 32 || key == 37 || key == 38 || key == 39 || key == 40);
  };

var check = function()
  {
  	if (document.getElementById('password').value ==
	document.getElementById('confirm_password').value) {
	document.getElementById('message').style.color = 'green';
	document.getElementById('message').innerHTML = 'Password & Confirm Password Matched';
	                      } else {
	document.getElementById('message').style.color = 'red';
	document.getElementById('message').innerHTML = 'Password & Confirm Password is not Matching';
                      }
                    }
 </script>
