<?php
	include 'includes/header.php';
  foreach ($soldProducts as $row) 
  {
    $sellerName = $row->sellerName;
  }
?>	
<title>My Products</title>
	<div class="container-fluid">
		<div class="container"><br><br><br>
      <?php
        if($countMyProducts>0)
        {
      ?>
						<h3 class="box-title text-center">All Products</h3><br>
            <h6 class="text-center">Dear <b><?=$sellerName;?></b> following are your sold products.</h6><br>
					<table class="table table-striped table-bordered">
						<thead>
							<th>Sr. No.</th>
              				<th>Category Name</th>
              				<th>Product Name</th>
              				<th>Price</th>
              				<th>Description</th>
             				<th>Status</th>
             				<th>Quantity</th>
             				<th>Start Date</th>
             				<th>End Date</th>
               				<th>Image</th>
						</thead>
						<tbody>
          					<?php
            					$counter = 0;
            					foreach ($soldProducts as $row) 
            					{
             						$srNo= ++$counter;
                        			$prodID = $row->prodID;
             						 $catName = $row->catName;
              						$prodName = $row->prodName;
              						$prodPrice = $row->prodPrice;
              						$description = $row->prodDescription;
              						$status = $row->prodStatus;
              						$prodQuantity = $row->prodQuantity;
              						$startDate = $row->prodStartDate;
              						$endDate = $row->prodEndDate;
              						$image = $row->prodImage;			
         			 		?>
              						<tr>
									<td><?=$srNo; ?></td>
                					<td><?=$catName; ?></td>
                					<td><?=$prodName; ?></td>
                					<td><?=$prodPrice; ?></td>
                					<td><?=$description; ?></td>
                					<td><?=$status; ?></td>
                					<td><?=$prodQuantity; ?></td>
                					<td><?=$startDate; ?></td>
                					<td><?=$endDate; ?></td>	
                					<td><img src="<?=base_url();?>/assets/images/ProductsImage/<?=$image; ?>" class="img-responsive" style="width: 40px;height: 40px;"></td>
							</tr>
							<?php } ?>
						</tbody>
					</table><br><br>
				</div>
      <?php 
        }
        else
        {  
          echo '<div>
                  <h3 class="text-center">Dear seller you don\'t have any sold product yet.</h3><br><br><br>
                  </div>';
        }?>
			</div><!--/.row-->
		</div>
	</div>	<!--/.main-->
<?php
	include 'includes/footer.php';
	$this->load->view('alert');
?>