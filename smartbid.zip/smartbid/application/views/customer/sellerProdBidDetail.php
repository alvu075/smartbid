<?php include 'includes/header.php'; ?>
<title>Products</title>
    <section id="products" class="section">
      <div class="container">
        <div class="section-header">          
          <h2 class="section-title">All Bids Details</h2>
          <hr class="lines">
        </div>
        <?php
          $ID = 0;
          foreach ($allBids as $row) 
          {
            $ID = $row->bidID;
          }
          if($ID>0)
          { 
        ?>
        <div class="row">
          <div class="table">
            <table class="table table-striped table-bordered">
              <thead>
                <th>Sr. No.</th>
                <th>Category Name</th>
                <th>Product Name</th>
                <th>Bidder Name</th>
                <th>Bid Amount</th>
                <th>Date</th>
                <th>Time</th>
              </thead>
              <tbody>
                <?php
                  $counter = 0; 
                  foreach ($allBids as $row) 
                  { 
                    $srNo = ++$counter;
                    $catName = $row->catName;    
                    $prodName = $row->prodName;
                    $bidderName = $row->bidderName;
                    $bidAmount = $row->bidAmount;
                    $bidDate = $row->date;
                    $bidTime = $row->time;
                ?>

                  <tr>
                    <td><?=$srNo;?></td>
                    <td><?=$catName;?></td>
                    <td><?=$prodName;?></td>
                    <td><?=$bidderName;?></td>
                    <td><?=$bidAmount;?></td>
                    <td><?=$bidDate;?></td>
                    <td><?=$bidTime;?></td>
                  </tr>

                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
        <?php }
          else
          {
            echo "<div>
                  <h3 class='text-center'>No bid on your products yet.</h3>
                  </div>";
          }?>
        </div>
      </div>
    </section>

<?php
  include 'includes/footer.php';
  $this->load->view('alert');
?>